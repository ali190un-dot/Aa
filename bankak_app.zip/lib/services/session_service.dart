import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../core/constants.dart';
import '../core/security.dart';

enum AppSessionState {
  locked,
  unlocking,
  unlocked,
  protected, // Backgrounded with opaque curtain
  timedOut,
  loggedOut,
}

/// Section 6 & 9: Session, Timeout, and Lifecycle State Machine
class SessionService extends ChangeNotifier with WidgetsBindingObserver {
  final FlutterSecureStorage _storage;
  static const MethodChannel _touchChannel = MethodChannel(AppConstants.touchActivityChannel);

  AppSessionState _state = AppSessionState.locked;
  int _timeoutMinutes = AppConstants.defaultTimeoutMinutes;
  Timer? _inactivityTimer;
  DateTime _lastActivityTime = DateTime.now();

  // Internal flag to prevent lock loops during expected system dialogs (biometrics, external browser)
  bool _isExpectingSystemTransition = false;

  // Callback to signal WebView destruction and cleanup
  VoidCallback? onSessionResetRequired;

  SessionService({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage() {
    WidgetsBinding.instance.addObserver(this);
    _initTouchChannel();
    _loadTimeoutSetting();
  }

  AppSessionState get state => _state;
  int get timeoutMinutes => _timeoutMinutes;
  bool get isUnlocked => _state == AppSessionState.unlocked;
  bool get isProtected => _state == AppSessionState.protected;

  void _initTouchChannel() {
    _touchChannel.setMethodCallHandler((call) async {
      if (call.method == 'onTouchActivity') {
        // MethodChannel sends timestamp only (ev.action == ACTION_DOWN)
        recordUserActivity();
      }
    });
  }

  Future<void> _loadTimeoutSetting() async {
    final value = await _storage.read(key: AppConstants.keyTimeoutMinutes);
    if (value != null) {
      final parsed = int.tryParse(value);
      if (parsed != null && AppConstants.timeoutOptionsMinutes.contains(parsed)) {
        _timeoutMinutes = parsed;
        notifyListeners();
      }
    }
  }

  Future<void> setTimeoutMinutes(int minutes) async {
    if (AppConstants.timeoutOptionsMinutes.contains(minutes)) {
      _timeoutMinutes = minutes;
      await _storage.write(
        key: AppConstants.keyTimeoutMinutes,
        value: minutes.toString(),
      );
      if (isUnlocked) {
        _resetInactivityTimer();
      }
      notifyListeners();
    }
  }

  /// Mark start of an expected transition (e.g. system biometric dialog or browser launch)
  void setExpectedTransition(bool isExpecting) {
    _isExpectingSystemTransition = isExpecting;
  }

  /// Transition state to unlocked upon verified biometric or PIN entry
  void unlockSession() {
    _state = AppSessionState.unlocked;
    _lastActivityTime = DateTime.now();
    _resetInactivityTimer();
    notifyListeners();
  }

  /// Resets the inactivity timer upon verified touch activity
  void recordUserActivity() {
    if (_state != AppSessionState.unlocked) return;
    _lastActivityTime = DateTime.now();
    _resetInactivityTimer();
  }

  void _resetInactivityTimer() {
    _inactivityTimer?.cancel();
    _inactivityTimer = Timer(Duration(minutes: _timeoutMinutes), _handleTimeout);
  }

  /// Handles inactivity timeout
  void _handleTimeout() {
    if (_state == AppSessionState.unlocked || _state == AppSessionState.protected) {
      SecureLogger.log('Inactivity timeout reached. Destroying WebView and locking session.');
      _inactivityTimer?.cancel();
      _state = AppSessionState.timedOut;
      onSessionResetRequired?.call();
      notifyListeners();
    }
  }

  /// Handles explicit user logout
  void performLogout() {
    _inactivityTimer?.cancel();
    _state = AppSessionState.loggedOut;
    onSessionResetRequired?.call();
    notifyListeners();
  }

  /// Manual lock trigger
  void lock() {
    _inactivityTimer?.cancel();
    _state = AppSessionState.locked;
    notifyListeners();
  }

  /// Section 9: Lifecycle transitions (inactive, paused, detached, resumed)
  @override
  void didChangeAppLifecycleState(AppLifecycleState lifecycleState) {
    super.didChangeAppLifecycleState(lifecycleState);

    switch (lifecycleState) {
      case AppLifecycleState.inactive:
      case AppLifecycleState.paused:
      case AppLifecycleState.detached:
      case AppLifecycleState.hidden:
        if (_state == AppSessionState.unlocked && !_isExpectingSystemTransition) {
          // Immediately cover content with opaque Flutter overlay
          _state = AppSessionState.protected;
          notifyListeners();
        }
        break;

      case AppLifecycleState.resumed:
        if (_isExpectingSystemTransition) {
          // System prompt returned; reset flag
          _isExpectingSystemTransition = false;
          return;
        }

        // Check if timeout expired while app was backgrounded
        final elapsed = DateTime.now().difference(_lastActivityTime);
        if (elapsed >= Duration(minutes: _timeoutMinutes)) {
          _handleTimeout();
        } else if (_state == AppSessionState.protected) {
          // Always require local re-authentication upon resume
          _state = AppSessionState.locked;
          notifyListeners();
        }
        break;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _inactivityTimer?.cancel();
    super.dispose();
  }
}
