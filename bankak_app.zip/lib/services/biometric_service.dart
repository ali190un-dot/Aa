import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../core/constants.dart';
import '../core/security.dart';

/// Section 7: Biometric & Device Credential Authentication
/// The app never accesses or stores biometric data.
class BiometricService {
  final LocalAuthentication _localAuth;
  final FlutterSecureStorage _storage;

  BiometricService({LocalAuthentication? localAuth, FlutterSecureStorage? storage})
      : _localAuth = localAuth ?? LocalAuthentication(),
        _storage = storage ?? const FlutterSecureStorage();

  /// Checks if hardware and enrollment allow biometric or device lock
  Future<bool> canAuthenticateWithBiometrics() async {
    try {
      final isDeviceSupported = await _localAuth.isDeviceSupported();
      final canCheckBiometrics = await _localAuth.canCheckBiometrics;
      return isDeviceSupported && canCheckBiometrics;
    } on PlatformException catch (e) {
      SecureLogger.warn('Biometric check failed: ${e.message}');
      return false;
    }
  }

  /// Checks if user has enabled biometric login in settings
  Future<bool> isBiometricEnabled() async {
    final value = await _storage.read(key: AppConstants.keyBiometricEnabled);
    // Defaults to true if hardware is capable
    if (value == null) return true;
    return value == 'true';
  }

  Future<void> setBiometricEnabled(bool enabled) async {
    await _storage.write(
      key: AppConstants.keyBiometricEnabled,
      value: enabled.toString(),
    );
  }

  /// Initiates local authentication prompt.
  /// On failure or cancel: returns false. Never opens iBOK on failure.
  Future<bool> authenticate({required String localizedReason}) async {
    try {
      final isSupported = await canAuthenticateWithBiometrics();
      if (!isSupported) {
        return false;
      }

      final authenticated = await _localAuth.authenticate(
        localizedReason: localizedReason,
        options: const AuthenticationOptions(
          stickyAuth: true,
          biometricOnly: false, // Allows device PIN/pattern fallback
          useErrorDialogs: true,
        ),
      );

      return authenticated;
    } on PlatformException catch (e) {
      SecureLogger.warn('Authentication exception: ${e.code}');
      return false;
    }
  }
}
