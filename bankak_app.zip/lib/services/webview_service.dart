import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/constants.dart';
import '../core/security.dart';

/// Section 8: WebView Service and Controller Configuration
class WebViewService {
  WebViewController? _controller;
  final Function(String url, String domain, VoidCallback onConfirm)? onExternalLinkRequested;
  final Function(String errorMessage)? onNavigationError;

  WebViewService({
    this.onExternalLinkRequested,
    this.onNavigationError,
  });

  WebViewController? get controller => _controller;

  /// Creates and configures the hardened WebViewController.
  /// Section 6: "The WebView is never created until state is unlocked."
  WebViewController createSecureController({
    required BuildContext context,
    required VoidCallback onUserActivity,
    required void Function(bool isLoading) onLoadingChanged,
  }) {
    final controller = WebViewController();

    // Android-specific hardening
    if (controller.platform is AndroidWebViewController) {
      AndroidWebViewController.enableDebugging(false);
      final androidController = controller.platform as AndroidWebViewController;
      androidController.setMediaPlaybackRequiresUserGesture(true);
    }

    controller
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setNavigationDelegate(
        NavigationDelegate(
          onNavigationRequest: (NavigationRequest request) {
            final validation = UrlValidator.validate(request.url);

            if (validation.isValid) {
              return NavigationDecision.navigate;
            }

            // If it's an external candidate (e.g. mailto, tel, or external domain)
            if (validation.isExternalCandidate && validation.candidateUri != null) {
              final uri = validation.candidateUri!;
              final hostDisplay = uri.host.isNotEmpty ? uri.host : uri.scheme;

              onExternalLinkRequested?.call(
                request.url,
                hostDisplay,
                () => _launchExternalUrl(uri),
              );
            } else {
              onNavigationError?.call(validation.reason);
            }

            return NavigationDecision.prevent;
          },
          onPageStarted: (String url) {
            onLoadingChanged(true);
            onUserActivity();
          },
          onPageFinished: (String url) {
            onLoadingChanged(false);
            onUserActivity();
          },
          onWebResourceError: (WebResourceError error) {
            onLoadingChanged(false);
            SecureLogger.warn('WebResourceError: ${error.errorCode} - ${error.description}');
            if (error.isForMainFrame ?? true) {
              onNavigationError?.call(error.description);
            }
          },
        ),
      );

    _controller = controller;
    return controller;
  }

  /// Loads the initial banking URL
  Future<void> loadBankingPortal() async {
    if (_controller != null) {
      await _controller!.loadRequest(Uri.parse(AppConstants.ibokBaseUrl));
    }
  }

  /// Section 9 & 14: Clear local WebView data (cookies, cache, WebStorage)
  Future<void> clearAllLocalData() async {
    try {
      if (_controller != null) {
        await _controller!.clearCache();
        await _controller!.clearLocalStorage();
      }
      final cookieManager = WebViewCookieManager();
      await cookieManager.clearCookies();
      SecureLogger.log('WebView cookies, cache, and WebStorage cleared.');
    } catch (e) {
      SecureLogger.warn('Error clearing WebView data: $e');
    }
  }

  /// Destroys and cleans up the controller reference
  Future<void> destroy() async {
    await clearAllLocalData();
    _controller = null;
  }

  Future<void> _launchExternalUrl(Uri uri) async {
    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      SecureLogger.warn('Could not launch external URL: $e');
    }
  }
}
