import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../core/constants.dart';
import '../core/security.dart';

/// Section 7: App PIN Service
/// Enforces salted PBKDF2-HMAC-SHA256 (>= 210,000 iterations), Keystore-backed storage,
/// escalating lockout attempt limiting, and constant-time verification.
class PinService {
  final FlutterSecureStorage _storage;
  final Pbkdf2 _pbkdf2Algorithm;

  PinService({FlutterSecureStorage? storage})
      : _storage = storage ??
            const FlutterSecureStorage(
              aOptions: AndroidOptions(
                encryptedSharedPreferences: true,
                resetOnError: false,
              ),
            ),
        _pbkdf2Algorithm = Pbkdf2(
          macAlgorithm: Hmac.sha256(),
          iterations: AppConstants.pbkdf2Iterations,
          bits: 256,
        );

  /// Checks if an app PIN has already been initialized
  Future<bool> hasPin() async {
    final verifier = await _storage.read(key: AppConstants.keyPinVerifier);
    final salt = await _storage.read(key: AppConstants.keyPinSalt);
    return verifier != null && salt != null;
  }

  /// Sets or updates the 6+ digit app PIN using PBKDF2-HMAC-SHA256
  Future<bool> setPin(String rawPin) async {
    if (rawPin.length < AppConstants.minPinLength) {
      throw ArgumentError('PIN must be at least ${AppConstants.minPinLength} digits.');
    }

    // 1. Generate 32 bytes cryptographically secure random salt
    final random = Random.secure();
    final saltBytes = Uint8List(AppConstants.saltByteLength);
    for (int i = 0; i < AppConstants.saltByteLength; i++) {
      saltBytes[i] = random.nextInt(256);
    }

    // 2. Derive PBKDF2 key with 210,000 iterations
    final secretKey = SecretKey(utf8.encode(rawPin));
    final derivedKey = await _pbkdf2Algorithm.deriveKey(
      secretKey: secretKey,
      nonce: saltBytes,
    );
    final verifierBytes = await derivedKey.extractBytes();

    // 3. Persist salt and verifier in Android Keystore backed storage
    await _storage.write(
      key: AppConstants.keyPinSalt,
      value: base64Encode(saltBytes),
    );
    await _storage.write(
      key: AppConstants.keyPinVerifier,
      value: base64Encode(verifierBytes),
    );

    // Reset failed attempts upon successful pin change
    await _storage.delete(key: AppConstants.keyFailedAttempts);
    await _storage.delete(key: AppConstants.keyLockoutUntil);

    return true;
  }

  /// Validates a candidate PIN against the stored verifier.
  /// Handles attempt counting and lockout escalation.
  Future<PinVerificationResult> verifyPin(String candidatePin) async {
    // Check if device is currently locked out
    final lockoutSeconds = await getRemainingLockoutSeconds();
    if (lockoutSeconds > 0) {
      return PinVerificationResult(
        isSuccess: false,
        isLockedOut: true,
        remainingLockoutSeconds: lockoutSeconds,
      );
    }

    final storedVerifierBase64 = await _storage.read(key: AppConstants.keyPinVerifier);
    final storedSaltBase64 = await _storage.read(key: AppConstants.keyPinSalt);

    if (storedVerifierBase64 == null || storedSaltBase64 == null) {
      return const PinVerificationResult(
        isSuccess: false,
        isLockedOut: false,
        remainingLockoutSeconds: 0,
      );
    }

    final saltBytes = base64Decode(storedSaltBase64);
    final storedVerifier = base64Decode(storedVerifierBase64);

    // Derive PBKDF2 with candidate PIN and stored salt
    final candidateSecretKey = SecretKey(utf8.encode(candidatePin));
    final derivedKey = await _pbkdf2Algorithm.deriveKey(
      secretKey: candidateSecretKey,
      nonce: saltBytes,
    );
    final candidateVerifier = await derivedKey.extractBytes();

    // Constant-time comparison to prevent side-channel timing attacks
    final isMatch = constantTimeCompare(candidateVerifier, storedVerifier);

    if (isMatch) {
      // Clear failed attempts counter upon successful verification
      await _storage.delete(key: AppConstants.keyFailedAttempts);
      await _storage.delete(key: AppConstants.keyLockoutUntil);
      return const PinVerificationResult(
        isSuccess: true,
        isLockedOut: false,
        remainingLockoutSeconds: 0,
      );
    } else {
      // Record failure and check for lockout
      final currentFailures = await _getFailedAttempts() + 1;
      await _storage.write(
        key: AppConstants.keyFailedAttempts,
        value: currentFailures.toString(),
      );

      if (currentFailures >= AppConstants.maxFailedAttemptsBeforeLockout) {
        final lockoutIndex = min(
          currentFailures - AppConstants.maxFailedAttemptsBeforeLockout,
          AppConstants.lockoutDurationsSeconds.length - 1,
        );
        final lockoutSeconds = AppConstants.lockoutDurationsSeconds[lockoutIndex];
        final lockoutUntil = DateTime.now().millisecondsSinceEpoch + (lockoutSeconds * 1000);

        await _storage.write(
          key: AppConstants.keyLockoutUntil,
          value: lockoutUntil.toString(),
        );

        return PinVerificationResult(
          isSuccess: false,
          isLockedOut: true,
          remainingLockoutSeconds: lockoutSeconds,
        );
      }

      return const PinVerificationResult(
        isSuccess: false,
        isLockedOut: false,
        remainingLockoutSeconds: 0,
      );
    }
  }

  /// Calculates remaining lockout duration in seconds (persisted across restarts)
  Future<int> getRemainingLockoutSeconds() async {
    final lockoutUntilStr = await _storage.read(key: AppConstants.keyLockoutUntil);
    if (lockoutUntilStr == null) return 0;

    final lockoutUntil = int.tryParse(lockoutUntilStr) ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    final remainingMs = lockoutUntil - now;

    if (remainingMs <= 0) {
      await _storage.delete(key: AppConstants.keyLockoutUntil);
      return 0;
    }
    return (remainingMs / 1000).ceil();
  }

  Future<int> _getFailedAttempts() async {
    final attemptsStr = await _storage.read(key: AppConstants.keyFailedAttempts);
    return int.tryParse(attemptsStr ?? '0') ?? 0;
  }
}

class PinVerificationResult {
  final bool isSuccess;
  final bool isLockedOut;
  final int remainingLockoutSeconds;

  const PinVerificationResult({
    required this.isSuccess,
    required this.isLockedOut,
    required this.remainingLockoutSeconds,
  });
}
