import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../core/constants.dart';
import '../core/security.dart';

/// Section 10 & 12: Device Integrity & Screen Protection Service
class SecurityService {
  static const MethodChannel _securityChannel = MethodChannel(AppConstants.securityChannel);
  final FlutterSecureStorage _storage;

  SecurityService({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage();

  /// Queries native Android platform for su binaries or test-keys tags
  Future<bool> isDeviceCompromised() async {
    try {
      final bool? isCompromised = await _securityChannel.invokeMethod<bool>('checkDeviceIntegrity');
      return isCompromised ?? false;
    } on PlatformException catch (e) {
      SecureLogger.warn('Failed to query device integrity: ${e.message}');
      return false;
    }
  }

  /// Verifies that window FLAG_SECURE is active
  Future<bool> isFlagSecureActive() async {
    try {
      final bool? isSecure = await _securityChannel.invokeMethod<bool>('isFlagSecureActive');
      return isSecure ?? true;
    } on PlatformException catch (e) {
      SecureLogger.warn('Failed to verify FLAG_SECURE: ${e.message}');
      return true;
    }
  }

  /// Whether compromised devices should be blocked instead of warned
  Future<bool> shouldBlockOnCompromised() async {
    final value = await _storage.read(key: AppConstants.keyBlockCompromised);
    if (value == null) return AppConstants.defaultBlockOnCompromisedDevice;
    return value == 'true';
  }

  Future<void> setBlockOnCompromised(bool block) async {
    await _storage.write(
      key: AppConstants.keyBlockCompromised,
      value: block.toString(),
    );
  }
}
