import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../core/l10n.dart';
import '../services/biometric_service.dart';
import '../services/session_service.dart';

/// Single Biometric Authentication Screen
/// Directs straight to browsing https://ib.bok-sd.com/mfmbs/bok/cib/ upon biometric verification.
class LockScreen extends StatefulWidget {
  final BiometricService biometricService;
  final SessionService sessionService;
  final VoidCallback onUnlocked;
  final VoidCallback onToggleLocale;
  final Locale currentLocale;
  final String? bannerMessage;

  const LockScreen({
    super.key,
    required this.biometricService,
    required this.sessionService,
    required this.onUnlocked,
    required this.onToggleLocale,
    required this.currentLocale,
    this.bannerMessage,
  });

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  bool _isAuthenticating = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    // Prompt biometric authentication on screen load
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _triggerBiometricAuth();
    });
  }

  Future<void> _triggerBiometricAuth() async {
    if (_isAuthenticating) return;
    setState(() {
      _isAuthenticating = true;
      _errorMessage = null;
    });

    final success = await widget.biometricService.authenticate();

    if (mounted) {
      setState(() {
        _isAuthenticating = false;
      });

      if (success) {
        widget.onUnlocked();
      } else {
        setState(() {
          _errorMessage = widget.currentLocale.languageCode == 'ar'
              ? 'فشلت المصادقة البيومترية. يرجى المحاولة مرة أخرى.'
              : 'Biometric verification failed. Please try again.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isAr = widget.currentLocale.languageCode == 'ar';

    return Scaffold(
      backgroundColor: const Color(0xFF020617), // Deep Navy
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
          child: Column(
            children: [
              // Top Bar with Language Switcher
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: const Color(0xFF005A36),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        alignment: Alignment.center,
                        child: const Text(
                          'BOK',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            'iBOK CIB',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                          Text(
                            'Bank of Khartoum',
                            style: TextStyle(
                              color: Color(0xFF94A3B8),
                              fontSize: 10,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  TextButton.icon(
                    onPressed: widget.onToggleLocale,
                    icon: const Icon(Icons.language, size: 16, color: Color(0xFF94A3B8)),
                    label: Text(
                      isAr ? 'English' : 'العربية',
                      style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 12),
                    ),
                  ),
                ],
              ),

              const Spacer(),

              // Biometric Fingerprint Icon Button
              GestureDetector(
                onTap: _triggerBiometricAuth,
                child: Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF005A36).withOpacity(0.15),
                    border: Border.all(
                      color: const Color(0xFF10B981).withOpacity(0.4),
                      width: 2,
                    ),
                  ),
                  child: Center(
                    child: _isAuthenticating
                        ? const CircularProgressIndicator(
                            color: Color(0xFF10B981),
                            strokeWidth: 3,
                          )
                        : const Icon(
                            Icons.fingerprint,
                            size: 64,
                            color: Color(0xFF10B981),
                          ),
                  ),
                ),
              ),

              const SizedBox(height: 24),

              Text(
                isAr ? 'تسجيل دخول الشركات (CIB)' : 'Corporate Banking Login (CIB)',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              Text(
                isAr
                  ? 'استخدم البصمة البيومترية للدخول وتصفح الرابط المعتمد مباشرة'
                  : 'Authenticate with biometrics to browse the official corporate banking link',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Color(0xFF94A3B8),
                  fontSize: 12,
                ),
              ),

              const SizedBox(height: 16),

              // Target URL Badge
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFF0F172A),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF1E293B)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Icon(Icons.lock, size: 14, color: Color(0xFF10B981)),
                    SizedBox(width: 6),
                    Text(
                      'ib.bok-sd.com/mfmbs/bok/cib/',
                      style: TextStyle(
                        color: Color(0xFF6EE7B7),
                        fontSize: 11,
                        fontFamily: 'monospace',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),

              if (_errorMessage != null) ...[
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.red.shade900.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.red.shade700),
                  ),
                  child: Text(
                    _errorMessage!,
                    style: const TextStyle(color: Colors.redAccent, fontSize: 12),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],

              const SizedBox(height: 32),

              // Single Biometric Action Button
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: _isAuthenticating ? null : _triggerBiometricAuth,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF005A36),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    elevation: 4,
                  ),
                  icon: const Icon(Icons.fingerprint, size: 20),
                  label: Text(
                    isAr ? 'استخدام البصمة وتصفح الرابط' : 'Authenticate & Browse Link',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                ),
              ),

              const Spacer(),

              // Security Footer
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.security, size: 14, color: Color(0xFF10B981)),
                  SizedBox(width: 6),
                  Text(
                    'Hardware Biometrics • FLAG_SECURE Protected',
                    style: TextStyle(color: Color(0xFF64748B), fontSize: 11),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
