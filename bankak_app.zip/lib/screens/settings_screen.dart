import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../core/l10n.dart';
import '../services/biometric_service.dart';
import '../services/session_service.dart';
import '../services/webview_service.dart';
import 'about_screen.dart';

/// Section 14: Settings Screen
/// Controls local app security parameters.
/// Explicitly notes non-disableable protections (HTTPS-only, domain allowlist, TLS validation).
class SettingsScreen extends StatefulWidget {
  final SessionService sessionService;
  final WebViewService webViewService;
  final VoidCallback onLogout;
  final Locale currentLocale;
  final VoidCallback onToggleLocale;

  const SettingsScreen({
    super.key,
    required this.sessionService,
    required this.webViewService,
    required this.onLogout,
    required this.currentLocale,
    required this.onToggleLocale,
  });

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final BiometricService _biometricService = BiometricService();
  bool _isBioEnabled = true;
  bool _canUseBio = false;
  late int _selectedTimeout;

  @override
  void initState() {
    super.initState();
    _selectedTimeout = widget.sessionService.timeoutMinutes;
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final canBio = await _biometricService.canAuthenticateWithBiometrics();
    final isEnabled = await _biometricService.isBiometricEnabled();
    if (mounted) {
      setState(() {
        _canUseBio = canBio;
        _isBioEnabled = isEnabled;
      });
    }
  }

  Future<void> _handleClearLocalData() async {
    final strings = AppStrings(widget.currentLocale);
    await widget.webViewService.clearAllLocalData();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(strings.get('localDataClearedSuccess')),
          backgroundColor: const Color(0xFF0D5C3A),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final strings = AppStrings(widget.currentLocale);

    return Scaffold(
      appBar: AppBar(
        title: Text(strings.get('settings')),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 16),
        children: [
          // Section: Authentication
          if (_canUseBio) ...[
            SwitchListTile(
              secondary: const Icon(Icons.fingerprint),
              title: Text(strings.get('biometricsToggle')),
              value: _isBioEnabled,
              onChanged: (val) async {
                await _biometricService.setBiometricEnabled(val);
                setState(() {
                  _isBioEnabled = val;
                });
              },
            ),
            const Divider(),
          ],

          // Section: Inactivity Timeout
          ListTile(
            leading: const Icon(Icons.timer_outlined),
            title: Text(strings.get('lockTimeout')),
            subtitle: Text('$_selectedTimeout ${strings.get('minutes')}'),
            trailing: DropdownButton<int>(
              value: _selectedTimeout,
              items: AppConstants.timeoutOptionsMinutes.map((minutes) {
                return DropdownMenuItem<int>(
                  value: minutes,
                  child: Text('$minutes ${strings.get(minutes == 1 ? 'minute' : 'minutes')}'),
                );
              }).toList(),
              onChanged: (val) {
                if (val != null) {
                  widget.sessionService.setTimeoutMinutes(val);
                  setState(() {
                    _selectedTimeout = val;
                  });
                }
              },
            ),
          ),
          const Divider(),

          // Section: Language Switch
          ListTile(
            leading: const Icon(Icons.language),
            title: const Text('Language / اللغة'),
            subtitle: Text(widget.currentLocale.languageCode == 'ar' ? 'العربية' : 'English'),
            trailing: OutlinedButton(
              onPressed: widget.onToggleLocale,
              child: Text(widget.currentLocale.languageCode == 'ar' ? 'Switch to English' : 'التحويل إلى العربية'),
            ),
          ),
          const Divider(),

          // Section: Data & Session Cleanup
          ListTile(
            leading: const Icon(Icons.cleaning_services_outlined),
            title: Text(strings.get('clearLocalData')),
            onTap: _handleClearLocalData,
          ),
          ListTile(
            leading: const Icon(Icons.logout, color: Color(0xFFDC2626)),
            title: Text(
              strings.get('logout'),
              style: const TextStyle(color: Color(0xFFDC2626), fontWeight: FontWeight.bold),
            ),
            onTap: () {
              Navigator.of(context).pop();
              widget.onLogout();
            },
          ),
          const Divider(),

          // Section: Non-disableable Security Invariants
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              'Enforced Platform Security (Non-Disableable)',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary,
                letterSpacing: 0.5,
              ),
            ),
          ),
          const ListTile(
            dense: true,
            leading: Icon(Icons.verified_user_outlined, size: 20, color: Color(0xFF0D5C3A)),
            title: Text('HTTPS-Only & System Trust Anchors'),
            subtitle: Text('Cleartext traffic blocked. No user CAs allowed.'),
          ),
          const ListTile(
            dense: true,
            leading: Icon(Icons.domain_verification, size: 20, color: Color(0xFF0D5C3A)),
            title: Text('Strict Domain Allowlist'),
            subtitle: Text('Restricted to ib.bok-sd.com only.'),
          ),
          const ListTile(
            dense: true,
            leading: Icon(Icons.screenshot_outlined, size: 20, color: Color(0xFF0D5C3A)),
            title: Text('FLAG_SECURE Screen Shielding'),
            subtitle: Text('Screenshots and screen recordings permanently blocked.'),
          ),
          const Divider(),

          // Section: About & Compliance
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: Text(strings.get('about')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (ctx) => AboutScreen(currentLocale: widget.currentLocale),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
