import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../services/security_service.dart';

/// Section 4 & 6: Splash Screen
/// Static official branding only. No animation delay, no account data.
/// Immediately performs lightweight device integrity check then navigates to Lock screen.
class SplashScreen extends StatefulWidget {
  final VoidCallback onReady;
  final SecurityService securityService;

  const SplashScreen({
    super.key,
    required this.onReady,
    required this.securityService,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _performInitialCheck();
  }

  Future<void> _performInitialCheck() async {
    // Check integrity heuristics
    await widget.securityService.isDeviceCompromised();
    // Proceed immediately to lock screen without artificial delays
    if (mounted) {
      widget.onReady();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A), // Deep navy
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Logo placeholder / asset container
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'iBOK',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                    color: const Color(0xFF0D5C3A), // BOK Signature Green
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              AppConstants.appName,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Bank of Khartoum Internet Banking',
              style: TextStyle(
                fontSize: 14,
                color: Colors.white.withOpacity(0.7),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
