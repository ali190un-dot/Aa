import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../core/constants.dart';
import '../core/l10n.dart';
import '../services/session_service.dart';
import '../services/webview_service.dart';
import 'settings_screen.dart';

/// Section 8 & 14: Banking Screen
/// Minimal secure container hosting the official iBOK portal with strict guardrails.
/// No URL address bar, strict back-button handling, and external navigation confirmation.
class BankingScreen extends StatefulWidget {
  final SessionService sessionService;
  final WebViewService webViewService;
  final VoidCallback onLogoutRequested;
  final Locale currentLocale;
  final VoidCallback onToggleLocale;

  const BankingScreen({
    super.key,
    required this.sessionService,
    required this.webViewService,
    required this.onLogoutRequested,
    required this.currentLocale,
    required this.onToggleLocale,
  });

  @override
  State<BankingScreen> createState() => _BankingScreenState();
}

class _BankingScreenState extends State<BankingScreen> {
  late final WebViewController _controller;
  bool _isLoading = true;
  String? _fatalErrorMessage;

  @override
  void initState() {
    super.initState();
    _initWebView();
  }

  void _initWebView() {
    _controller = widget.webViewService.createSecureController(
      context: context,
      onUserActivity: () => widget.sessionService.recordUserActivity(),
      onLoadingChanged: (loading) {
        if (mounted) {
          setState(() {
            _isLoading = loading;
          });
        }
      },
    );

    widget.webViewService.loadBankingPortal();
  }

  /// Section 14: Android back button navigation handler
  Future<bool> _handlePopScope() async {
    final canGoBack = await _controller.canGoBack();
    if (canGoBack) {
      await _controller.goBack();
      return false;
    }

    // If at root of history: confirm-then-lock (never exit to still-open session silently)
    if (!mounted) return false;
    final strings = AppStrings(widget.currentLocale);
    final shouldLock = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(strings.get('backConfirmTitle')),
        content: Text(strings.get('backConfirmMessage')),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(strings.get('cancel')),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFF0D5C3A),
            ),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(strings.get('lockApp')),
          ),
        ],
      ),
    );

    if (shouldLock == true) {
      widget.sessionService.lock();
    }
    return false;
  }

  void _openSettings() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (ctx) => SettingsScreen(
          sessionService: widget.sessionService,
          webViewService: widget.webViewService,
          onLogout: widget.onLogoutRequested,
          currentLocale: widget.currentLocale,
          onToggleLocale: widget.onToggleLocale,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final strings = AppStrings(widget.currentLocale);

    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) {
        if (!didPop) {
          _handlePopScope();
        }
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Container(
            color: const Color(0xFF0F172A), // Dark executive header
            child: SafeArea(
              child: Row(
                children: [
                  // Back in WebView history
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new, size: 20, color: Colors.white),
                    tooltip: 'Back',
                    onPressed: () async {
                      if (await _controller.canGoBack()) {
                        await _controller.goBack();
                      } else {
                        _handlePopScope();
                      }
                    },
                  ),
                  // Refresh
                  IconButton(
                    icon: const Icon(Icons.refresh, size: 22, color: Colors.white),
                    tooltip: 'Refresh',
                    onPressed: () {
                      _controller.reload();
                    },
                  ),
                  const Spacer(),
                  // Secure Lock Indicator (Host verify badge)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0D5C3A).withOpacity(0.4),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFF10B981).withOpacity(0.5)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        Icon(Icons.lock, size: 14, color: Color(0xFF34D399)),
                        SizedBox(width: 6),
                        Text(
                          'ib.bok-sd.com',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.3,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  // Settings
                  IconButton(
                    icon: const Icon(Icons.tune, size: 20, color: Colors.white),
                    tooltip: strings.get('settings'),
                    onPressed: _openSettings,
                  ),
                  // App Logout Button
                  IconButton(
                    icon: const Icon(Icons.logout, size: 20, color: Color(0xFFF87171)),
                    tooltip: strings.get('logout'),
                    onPressed: widget.onLogoutRequested,
                  ),
                ],
              ),
            ),
          ),
        ),
        body: Stack(
          children: [
            // Hardened WebView container
            if (_fatalErrorMessage == null)
              WebViewWidget(controller: _controller),

            // Loading bar
            if (_isLoading && _fatalErrorMessage == null)
              const LinearProgressIndicator(
                backgroundColor: Colors.transparent,
                color: Color(0xFF0D5C3A),
                minHeight: 3,
              ),

            // Fatal Error Display (Section 13)
            if (_fatalErrorMessage != null)
              Container(
                color: Colors.white,
                padding: const EdgeInsets.all(32),
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.cloud_off_outlined,
                        size: 64,
                        color: Color(0xFFDC2626),
                      ),
                      const SizedBox(height: 20),
                      Text(
                        _fatalErrorMessage!,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1F2937),
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 28),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          OutlinedButton.icon(
                            onPressed: () {
                              setState(() {
                                _fatalErrorMessage = null;
                              });
                              _controller.reload();
                            },
                            icon: const Icon(Icons.refresh),
                            label: Text(strings.get('retry')),
                          ),
                          const SizedBox(width: 16),
                          FilledButton.icon(
                            style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFF0D5C3A),
                            ),
                            onPressed: () {
                              widget.sessionService.lock();
                            },
                            icon: const Icon(Icons.lock_outline),
                            label: Text(strings.get('returnToLock')),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
