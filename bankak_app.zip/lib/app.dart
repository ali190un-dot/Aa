import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'core/constants.dart';
import 'core/l10n.dart';
import 'services/biometric_service.dart';
import 'services/pin_service.dart';
import 'services/security_service.dart';
import 'services/session_service.dart';
import 'services/webview_service.dart';
import 'screens/splash_screen.dart';
import 'screens/lock_screen.dart';
import 'screens/banking_screen.dart';
import 'widgets/secure_overlay.dart';

class IbokBankingApp extends StatefulWidget {
  const IbokBankingApp({super.key});

  @override
  State<IbokBankingApp> createState() => _IbokBankingAppState();
}

class _IbokBankingAppState extends State<IbokBankingApp> {
  late final PinService _pinService;
  late final BiometricService _biometricService;
  late final SecurityService _securityService;
  late final SessionService _sessionService;
  WebViewService? _webViewService;

  bool _isSplashFinished = false;
  Locale _locale = const Locale('en');

  @override
  void initState() {
    super.initState();
    _pinService = PinService();
    _biometricService = BiometricService();
    _securityService = SecurityService();
    _sessionService = SessionService();

    // Clean up WebView when session requires reset (timeout or logout)
    _sessionService.onSessionResetRequired = _handleSessionReset;
  }

  void _handleSessionReset() {
    _webViewService?.destroy();
    _webViewService = null;
  }

  void _toggleLocale() {
    setState(() {
      _locale = _locale.languageCode == 'en' ? const Locale('ar') : const Locale('en');
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      locale: _locale,
      supportedLocales: const [
        Locale('en', ''),
        Locale('ar', ''),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0D5C3A),
          brightness: Brightness.light,
        ),
      ),
      home: AnimatedBuilder(
        animation: _sessionService,
        builder: (context, child) {
          // 1. Initial Splash Screen
          if (!_isSplashFinished) {
            return SplashScreen(
              securityService: _securityService,
              onReady: () {
                setState(() {
                  _isSplashFinished = true;
                });
              },
            );
          }

          final state = _sessionService.state;
          final strings = AppStrings(_locale);

          // 2. Unlocked state: Mount secure Banking Screen
          if (state == AppSessionState.unlocked) {
            _webViewService ??= WebViewService(
              onExternalLinkRequested: (url, domain, onConfirm) {
                _showExternalLinkDialog(domain, onConfirm);
              },
            );

            return Stack(
              children: [
                BankingScreen(
                  sessionService: _sessionService,
                  webViewService: _webViewService!,
                  onLogoutRequested: () {
                    _sessionService.performLogout();
                  },
                  currentLocale: _locale,
                  onToggleLocale: _toggleLocale,
                ),
                // Cover with opaque curtain if protected (backgrounded)
                if (_sessionService.isProtected) const SecureOverlay(),
              ],
            );
          }

          // 3. Locked, TimedOut, or LoggedOut states
          String? bannerMessage;
          if (state == AppSessionState.timedOut) {
            bannerMessage = strings.get('sessionExpiredMessage');
          } else if (state == AppSessionState.loggedOut) {
            bannerMessage = strings.get('loggedOutMessage');
          }

          return Stack(
            children: [
              LockScreen(
                biometricService: _biometricService,
                sessionService: _sessionService,
                currentLocale: _locale,
                onToggleLocale: _toggleLocale,
                bannerMessage: bannerMessage,
                onUnlocked: () {
                  _sessionService.unlock();
                  setState(() {});
                },
              ),
              // If app is backgrounded while on lock screen
              if (_sessionService.isProtected) const SecureOverlay(),
            ],
          );
        },
      ),
    );
  }

  void _showExternalLinkDialog(String domain, VoidCallback onConfirm) {
    final strings = AppStrings(_locale);
    _sessionService.setExpectedTransition(true);

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(strings.get('externalLinkWarningTitle')),
        content: Text(
          strings.get('externalLinkWarningMessage').replaceAll('%s', domain),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop();
              _sessionService.setExpectedTransition(false);
            },
            child: Text(strings.get('cancel')),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFF0D5C3A),
            ),
            onPressed: () {
              Navigator.of(ctx).pop();
              onConfirm();
              // Transition flag reset when app resumes
            },
            child: Text(strings.get('proceed')),
          ),
        ],
      ),
    );
  }
}
