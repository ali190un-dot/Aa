/// Centralized constants for iBOK Banking
/// Section 5: "Centralize in core/constants: the base URL, one domain allowlist, timeout options, grace periods. No scattered literals."

class AppConstants {
  // Official Bank of Khartoum iBOK Retail Banking URL for Individuals (Strictly HTTPS)
  static const String ibokBaseUrl = 'https://ib.bok-sd.com/mfmbs/bok/rib/';

  // Strict Domain Allowlist - Exact host match only. Subdomains are not auto-allowed.
  static const Set<String> allowedHosts = {
    'ib.bok-sd.com',
  };

  // Supported Inactivity Timeout options in minutes (default is 5 minutes)
  static const List<int> timeoutOptionsMinutes = [1, 5, 10, 15];
  static const int defaultTimeoutMinutes = 5;

  // Minimum PIN length
  static const int minPinLength = 6;

  // Salt & PBKDF2 Iteration count (>= 210,000 as per specification Section 7)
  static const int pbkdf2Iterations = 210000;
  static const int saltByteLength = 32;

  // Attempt limiting: 5 failures -> escalating lockout schedules in seconds
  static const int maxFailedAttemptsBeforeLockout = 5;
  static const List<int> lockoutDurationsSeconds = [
    30,   // 1st lockout
    60,   // 2nd lockout
    300,  // 3rd lockout (5 min)
    900,  // 4th lockout (15 min)
    3600, // 5th+ lockout (1 hr)
  ];

  // MethodChannels
  static const String touchActivityChannel = 'com.ibok.banking/touch_activity';
  static const String securityChannel = 'com.ibok.banking/security';

  // Secure Storage Keys
  static const String keyPinSalt = 'ibok_sec_pin_salt';
  static const String keyPinVerifier = 'ibok_sec_pin_verifier';
  static const String keyFailedAttempts = 'ibok_sec_failed_attempts';
  static const String keyLockoutUntil = 'ibok_sec_lockout_until';
  static const String keyBiometricEnabled = 'ibok_sec_bio_enabled';
  static const String keyTimeoutMinutes = 'ibok_sec_timeout_minutes';
  static const String keyBlockCompromised = 'ibok_sec_block_compromised';

  // Section 12: Device integrity flag (default false = warn only)
  static const bool defaultBlockOnCompromisedDevice = false;

  // Section 4: Brand & Independence Disclosure
  static const String appName = 'iBOK Banking';
  static const String logoAssetPath = 'assets/branding/logo.png';
  static const String logoPlaceholderPath = '<<LOGO_PATH – ask the user; do not proceed with icons until provided>>';
}
