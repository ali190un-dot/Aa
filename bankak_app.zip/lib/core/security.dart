import 'package:flutter/foundation.dart';
import 'constants.dart';

/// Section 8 & 13: Secure URL Validator, Navigation Policy, and Safe Logger
class UrlValidator {
  /// Validates if a target URI string is authorized to load in the secure WebView.
  /// Enforces:
  /// - Scheme must be strictly 'https'
  /// - Port must be default (null or 443)
  /// - No userInfo (credentials in URI are strictly forbidden)
  /// - Host must exactly match the allowlist (no auto-allowed subdomains or lookalikes)
  static UrlValidationResult validate(String rawUrl) {
    if (rawUrl.trim().isEmpty) {
      return const UrlValidationResult(
        isValid: false,
        reason: 'Empty URL',
      );
    }

    final Uri? uri = Uri.tryParse(rawUrl.trim());
    if (uri == null) {
      return const UrlValidationResult(
        isValid: false,
        reason: 'Malformed URL format',
      );
    }

    // 1. Enforce HTTPS scheme strictly
    final scheme = uri.scheme.toLowerCase();
    if (scheme != 'https') {
      _logBlockedHost(uri.host, 'Rejected non-HTTPS scheme: $scheme');
      return UrlValidationResult(
        isValid: false,
        reason: 'Only HTTPS connections are allowed (blocked scheme: $scheme)',
        isExternalCandidate: scheme == 'tel' || scheme == 'mailto' || scheme == 'http',
        candidateUri: uri,
      );
    }

    // 2. Enforce standard HTTPS port only
    if (uri.hasPort && uri.port != 443) {
      _logBlockedHost(uri.host, 'Rejected non-standard port: ${uri.port}');
      return UrlValidationResult(
        isValid: false,
        reason: 'Non-standard port ${uri.port} is forbidden',
      );
    }

    // 3. UserInfo is strictly forbidden (e.g., https://attacker@ib.bok-sd.com)
    if (uri.userInfo.isNotEmpty) {
      _logBlockedHost(uri.host, 'Rejected URL containing userInfo');
      return const UrlValidationResult(
        isValid: false,
        reason: 'Embedded user credentials in URL are forbidden',
      );
    }

    // 4. Host validation: exact allowlist match
    final host = uri.host.toLowerCase();
    if (host.isEmpty) {
      return const UrlValidationResult(
        isValid: false,
        reason: 'Missing hostname',
      );
    }

    // Reject IP addresses or IDN homograph anomalies
    if (AppConstants.allowedHosts.contains(host)) {
      return UrlValidationResult(
        isValid: true,
        reason: 'Authorized domain',
        candidateUri: uri,
      );
    } else {
      _logBlockedHost(host, 'Host not in allowlist');
      return UrlValidationResult(
        isValid: false,
        reason: 'Domain $host is not in the allowed banking list',
        isExternalCandidate: true,
        candidateUri: uri,
      );
    }
  }

  /// Section 8 & 13: Log ONLY the host (never path, query, or token) in debug mode.
  /// No-op in release builds.
  static void _logBlockedHost(String host, String reason) {
    if (kDebugMode) {
      // ignore: avoid_print
      debugPrint('[iBOK Security] Navigation blocked for host: $host ($reason)');
    }
  }
}

class UrlValidationResult {
  final bool isValid;
  final String reason;
  final bool isExternalCandidate;
  final Uri? candidateUri;

  const UrlValidationResult({
    required this.isValid,
    required this.reason,
    this.isExternalCandidate = false,
    this.candidateUri,
  });
}

/// Constant-time comparison helper to resist timing attacks (Section 7)
bool constantTimeCompare(List<int> a, List<int> b) {
  if (a.length != b.length) {
    return false;
  }
  int result = 0;
  for (int i = 0; i < a.length; i++) {
    result |= a[i] ^ b[i];
  }
  return result == 0;
}

/// Minimal release-safe logger (Section 13: no prints in release)
class SecureLogger {
  static void log(String message) {
    if (kDebugMode) {
      debugPrint('[iBOK] $message');
    }
  }

  static void warn(String message) {
    if (kDebugMode) {
      debugPrint('[iBOK WARNING] $message');
    }
  }
}
