import 'package:flutter/material.dart';

/// Section 14: PinKeypad with large touch targets, high contrast, and haptic feedback.
class PinKeypad extends StatelessWidget {
  final void Function(String digit) onDigitPressed;
  final VoidCallback onDeletePressed;
  final VoidCallback? onSubmitPressed;
  final bool isSubmitEnabled;

  const PinKeypad({
    super.key,
    required this.onDigitPressed,
    required this.onDeletePressed,
    this.onSubmitPressed,
    this.isSubmitEnabled = false,
  });

  Widget _buildKey(BuildContext context, String label, {VoidCallback? onPressed, Widget? icon}) {
    return Container(
      margin: const EdgeInsets.all(6),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(40),
          onTap: onPressed ?? () => onDigitPressed(label),
          child: Container(
            height: 64,
            width: 64,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.5),
                width: 1.5,
              ),
              color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
            ),
            child: icon ??
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
                ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildKey(context, '1'),
            _buildKey(context, '2'),
            _buildKey(context, '3'),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildKey(context, '4'),
            _buildKey(context, '5'),
            _buildKey(context, '6'),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildKey(context, '7'),
            _buildKey(context, '8'),
            _buildKey(context, '9'),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Left action: Submit if present, otherwise empty placeholder
            onSubmitPressed != null
                ? _buildKey(
                    context,
                    '',
                    onPressed: isSubmitEnabled ? onSubmitPressed : null,
                    icon: Icon(
                      Icons.check,
                      color: isSubmitEnabled
                          ? Theme.of(context).colorScheme.primary
                          : Theme.of(context).colorScheme.outline.withOpacity(0.4),
                    ),
                  )
                : const SizedBox(width: 76, height: 76),
            _buildKey(context, '0'),
            _buildKey(
              context,
              'del',
              onPressed: onDeletePressed,
              icon: Icon(
                Icons.backspace_outlined,
                color: Theme.of(context).colorScheme.onSurface,
                size: 22,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
