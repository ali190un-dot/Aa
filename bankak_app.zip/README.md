# iBOK Banking — Secure Android Container

Production-grade secure Android container for the official Bank of Khartoum iBOK Internet Banking service:
`https://ib.bok-sd.com/mfmbs/bok/rib/#/`

This application acts as a hardened, dedicated native Android perimeter around the official web banking portal. The official website remains solely responsible for username, password, OTP, MFA, CAPTCHA, authorization, server-side sessions, accounts, and financial transactions.

---

## 1. Architecture Summary

```
lib/
  main.dart                      # Orientation lock & entry point
  app.dart                       # State machine coordinator & MaterialApp (RTL/LTR)
  core/
    constants.dart               # Allowlist, endpoints, timeouts, salt sizes, lockout schedule
    security.dart                # UrlValidator, constantTimeCompare, SecureLogger
    l10n.dart                    # Dual-language translations (Arabic & English)
  services/
    biometric_service.dart       # local_auth integration & hardware availability checks
    pin_service.dart             # PBKDF2-HMAC-SHA256 (210,000 iterations), Keystore verifiers, lockout
    session_service.dart         # State machine, touch timestamp listener, inactivity timer, lifecycle
    security_service.dart        # Device integrity heuristics & FLAG_SECURE status
    webview_service.dart         # Hardened WebViewController, NavigationDelegate, cache cleanup
  screens/
    splash_screen.dart           # Static official branding & device integrity check
    lock_screen.dart             # Biometric authentication & 6-digit PIN keypad with lockout
    banking_screen.dart          # Hardened WebView host, custom header, back-button safety
    settings_screen.dart         # Timeouts, biometrics toggle, clear local data, security info
    about_screen.dart            # Independence disclosure & compliance statement
  widgets/
    secure_overlay.dart          # Opaque screen curtain for backgrounded state
    pin_keypad.dart              # Accessible large-touch PIN keypad

android/app/src/main/
  kotlin/.../MainActivity.kt    # FlutterFragmentActivity, permanent FLAG_SECURE, dispatchTouchEvent
  AndroidManifest.xml           # INTERNET permission only, usesCleartextTraffic="false", backup disabled
  res/xml/
    network_security_config.xml # System-only trust anchors (no user CAs), cleartext disabled
    data_extraction_rules.xml   # Cloud and device transfer disabled
    backup_rules.xml            # Full backup disabled
```

---

## 2. Dependency Justification & Pinned Versions

| Dependency | Version | Justification |
| :--- | :--- | :--- |
| `webview_flutter` | `^4.7.0` | Official, actively maintained Flutter WebView plugin for rendering web content. |
| `webview_flutter_android` | `^3.16.0` | Android-specific implementation providing fine-grained debugging control and configuration. |
| `local_auth` | `^2.2.0` | Official biometric authentication plugin supporting fingerprint, face, and device credential. |
| `flutter_secure_storage` | `^9.2.1` | Android Keystore backed storage (`EncryptedSharedPreferences`) for storing the PIN salt and PBKDF2 verifier. |
| `cryptography` | `^2.7.0` | Pure-Dart cryptographic library executing salted PBKDF2-HMAC-SHA256 with 210,000 iterations. |
| `flutter_localizations` | `sdk: flutter` | Core localization framework for English and Arabic. |
| `intl` | `^0.19.0` | Date and text internationalization. |
| `url_launcher` | `^6.3.0` | Dedicated launcher for explicit, user-confirmed external links (`tel:`, `mailto:`, external domains). |

**SDK Constraints:**
- `minSdk`: 24 (Android 7.0 Nougat)
- `targetSdk`: 34 (Android 14)
- `compileSdk`: 34
- Flutter: `>=3.3.0 <4.0.0`

---

## 3. Assumptions and Architectural Decisions

1. **Screen Protection (`FLAG_SECURE`):**
   - Implemented at the native `MainActivity.onCreate()` level and kept active for the entire application lifetime.
   - Prevents screenshots, screen recording, and system recents previews from leaking banking data.
2. **Activity Detection Inside WebView:**
   - Touch gestures inside a WebView do not bubble up to Flutter widgets.
   - Decided to override `dispatchTouchEvent` in `MainActivity.kt` and send *only* a timestamp (`System.currentTimeMillis()`) across `com.ibok.banking/touch_activity`.
   - Coordinates (x, y), pointer IDs, and screen contents are strictly never transmitted or recorded.
3. **App PIN vs Bank Authentication:**
   - The App PIN only unlocks the local container. It never replaces the bank's password, OTP, or MFA.
   - Attempt limiting: 5 failed attempts locks the user out with escalating timers: 30s, 60s, 300s, 900s, 3600s.
   - Stored using PBKDF2-HMAC-SHA256 with 210,000 iterations and a 32-byte cryptographically secure salt.
4. **Subresource Limitation:**
   - NavigationDelegate intercepts document and iframe navigations. Subresource requests (internal scripts, images, CDNs) are not intercepted because request interception (`shouldInterceptRequest`) is forbidden by the banking boundary.
5. **No Deep Links / No Incoming URLs:**
   - The app rejects incoming intent filters (except `android.intent.action.MAIN` with `CATEGORY_LAUNCHER`). No external URL can force navigation inside the container.
6. **Independence Disclosure:**
   - Section 4 requires an explicit disclosure: This application is an independent client container providing secure access to the official iBOK website and is not published or endorsed by Bank of Khartoum.

---

## 4. Known Limitations

- **Downloads and File Uploads:** Not supported in version 1.0.0. No storage permissions are requested or used.
- **Subresource Filtering:** Modern WebViews do not permit fine-grained subresource URL filtering without request interception (MITM proxying), which is prohibited by the banking boundary. Main-frame navigation is strictly confined to `ib.bok-sd.com`.
- **Server Session Management:** The native container cannot manipulate the bank's server-side session without executing unauthorized JavaScript. When the user taps "Logout" in the app header, local cookies and storage are cleared, but users are reminded to click the bank portal's logout button first.

---

## 5. Domain Allowlist Maintenance

The single source of truth for allowed domains is located in `lib/core/constants.dart`:
```dart
static const Set<String> allowedHosts = {
  'ib.bok-sd.com',
};
```
If Bank of Khartoum migrates or adds an official authentication endpoint, add the exact hostname with a comment explaining the authorization. Lookalikes, IP addresses, and subdomains are never automatically allowed.

---

## 6. Release Signing Instructions

1. Generate your release keystore using the standard Android keytool:
   ```bash
   keytool -genkey -v -keystore ibok-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias ibok_release
   ```
2. Copy `android/key.properties.example` to `android/key.properties` (this file is gitignored):
   ```properties
   storePassword=YOUR_STORE_PASSWORD
   keyPassword=YOUR_KEY_PASSWORD
   keyAlias=ibok_release
   storeFile=../ibok-release-key.jks
   ```
3. Build the release APK or Android App Bundle:
   ```bash
   # Release APK
   flutter build apk --release

   # Google Play App Bundle
   flutter build appbundle --release
   ```

---

## 7. Verification Report & Manual Device Checklist

### Automated & Static Verification
- [x] **URL Validator:** Verified against lookalikes (`ib.bok-sd.com.evil.com`, `evilib.bok-sd.com`), userinfo, non-standard ports, invalid schemes.
- [x] **PIN Cryptography:** Verified constant-time comparison, PBKDF2-HMAC-SHA256 iteration threshold (≥210,000), escalating lockout schedules.
- [x] **Android Manifest Audit:** Verified single `INTERNET` permission, `usesCleartextTraffic="false"`, `allowBackup="false"`, system-only trust anchors.
- [x] **Static Code Analysis:** Verified absence of JS injection (`evaluateJavascript`/`runJavaScript`), cert bypass (`onReceivedSslError`), and plain `print` statements.

### Manual Device Checklist (Physical Device Required)
*The following require execution on a physical Android handset with hardware security modules and live network access:*

- [ ] **UNVERIFIED – manual check required:** Biometric authentication (Fingerprint / Face Unlock) enrollment, success, cancellation, and fallback to 6-digit PIN.
- [ ] **UNVERIFIED – manual check required:** `FLAG_SECURE` blocks screenshots via hardware buttons and displays a blank card in the Android Recents / App Switcher overview.
- [ ] **UNVERIFIED – manual check required:** Inactivity timeout timer locks app after 1, 5, 10, or 15 minutes of idle time.
- [ ] **UNVERIFIED – manual check required:** Screen touches inside the WebView successfully propagate timestamp signals via `dispatchTouchEvent` to reset the inactivity timer.
- [ ] **UNVERIFIED – manual check required:** Home button backgrounding immediately triggers opaque curtain, and app resumption enforces re-authentication.
- [ ] **UNVERIFIED – manual check required:** Live Bank of Khartoum iBOK site loads, and interactive SMS/OTP login completes without rendering glitches.
- [ ] **UNVERIFIED – manual check required:** Untrusted or user-installed TLS CA certificates (e.g., Charles Proxy / mitmproxy) are rejected by the network security config.
- [ ] **UNVERIFIED – manual check required:** `adb shell dumpsys package com.ibok.banking` confirms only `android.permission.INTERNET` is granted.
- [ ] **UNVERIFIED – manual check required:** `chrome://inspect` in release build fails to attach to the WebView (`setWebContentsDebuggingEnabled(false)`).
