package com.ibok.banking

import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.WindowManager
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

/**
 * MainActivity for iBOK Banking.
 *
 * Implements:
 * 1. FlutterFragmentActivity: Required by local_auth for biometric prompts on Android.
 * 2. FLAG_SECURE: Blocks screenshots, screen recording, and recents preview permanently.
 * 3. In-WebView Touch Detection: Dispatches touch timestamp signals (no coordinates) via MethodChannel.
 * 4. Tapjacking Protection: Detects obscured touch events (FLAG_WINDOW_IS_OBSCURED).
 * 5. Device Integrity Heuristics: Checks build tags and su binary indicators without external APIs.
 */
class MainActivity : FlutterFragmentActivity() {

    private val TOUCH_CHANNEL_NAME = "com.ibok.banking/touch_activity"
    private val SECURITY_CHANNEL_NAME = "com.ibok.banking/security"

    private var touchChannel: MethodChannel? = null
    private var securityChannel: MethodChannel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Section 10: Screen Protection - FLAG_SECURE set at MainActivity level for app lifetime
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // Touch activity channel for resetting session inactivity timer
        touchChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, TOUCH_CHANNEL_NAME)

        // Security channel for device integrity and secure flag status
        securityChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, SECURITY_CHANNEL_NAME)
        securityChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "checkDeviceIntegrity" -> {
                    val compromised = checkDeviceIntegrityHeuristics()
                    result.success(compromised)
                }
                "isFlagSecureActive" -> {
                    val isSecure = (window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE) != 0
                    result.success(isSecure)
                }
                else -> result.notImplemented()
            }
        }
    }

    /**
     * Section 9: Activity Detection inside WebView.
     * Touches inside a WebView do not reach Flutter widgets.
     * We override dispatchTouchEvent and send ONLY a timestamp signal over the MethodChannel.
     * Never transmit coordinates (x, y), pointer IDs, or screen content.
     */
    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (ev != null) {
            // Anti-tapjacking check: reject obscured touches from floating overlays
            val isObscured = (ev.flags and MotionEvent.FLAG_WINDOW_IS_OBSCURED) != 0 ||
                    (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                     (ev.flags and MotionEvent.FLAG_WINDOW_IS_PARTIALLY_OBSCURED) != 0)

            if (isObscured) {
                // Ignore touch to resist overlay tapjacking
                return false
            }

            if (ev.action == MotionEvent.ACTION_DOWN) {
                // Send ONLY the timestamp in milliseconds (no coordinates, no touch data)
                touchChannel?.invokeMethod("onTouchActivity", System.currentTimeMillis())
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    /**
     * Section 12: Lightweight device integrity heuristics.
     * Checks build tags ('test-keys') and common su binary locations.
     * Does not require external APIs or Google Play services.
     */
    private fun checkDeviceIntegrityHeuristics(): Boolean {
        val buildTags = Build.TAGS
        if (buildTags != null && buildTags.contains("test-keys")) {
            return true
        }

        val suPaths = arrayOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su"
        )

        for (path in suPaths) {
            try {
                if (File(path).exists()) {
                    return true
                }
            } catch (_: Exception) {
                // Ignore security exceptions during read attempt
            }
        }

        return false
    }
}
