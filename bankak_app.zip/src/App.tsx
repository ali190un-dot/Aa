import React, { useState, useEffect } from 'react';
import {
  Fingerprint,
  RefreshCw,
  LogOut,
  ExternalLink,
  Lock,
  Globe
} from 'lucide-react';
import bankakLogo from './assets/images/bankak_icon_1791184108073.jpg';

const IBOK_URL = 'https://ib.bok-sd.com/mfmbs/bok/rib/';

export default function App() {
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [splashFadeOut, setSplashFadeOut] = useState<boolean>(false);
  const [splashProgress, setSplashProgress] = useState<number>(15);

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isAuthenticating, setIsAuthenticating] = useState<boolean>(false);
  const [lang, setLang] = useState<'ar' | 'en'>('ar');
  const [iframeKey, setIframeKey] = useState<number>(1);

  // Clean Splash Screen: elegant loading, no technical text
  useEffect(() => {
    const p1 = setTimeout(() => setSplashProgress(60), 400);
    const p2 = setTimeout(() => setSplashProgress(100), 1100);

    const fadeTimer = setTimeout(() => {
      setSplashFadeOut(true);
    }, 1600);

    const finishTimer = setTimeout(() => {
      setShowSplash(false);
    }, 2000);

    return () => {
      clearTimeout(p1);
      clearTimeout(p2);
      clearTimeout(fadeTimer);
      clearTimeout(finishTimer);
    };
  }, []);

  // Biometric Authentication Handler: directly uses device-registered biometrics
  const handleBiometricAuth = async () => {
    setIsAuthenticating(true);

    try {
      if (window.PublicKeyCredential) {
        const available = await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable().catch(() => false);
        if (available && navigator.credentials) {
          try {
            const challenge = new Uint8Array(32);
            window.crypto.getRandomValues(challenge);
            const userSub = new Uint8Array(16);
            window.crypto.getRandomValues(userSub);

            // Directly invokes the device's registered fingerprint / biometric sensor
            await navigator.credentials.create({
              publicKey: {
                challenge,
                rp: {
                  name: 'Bankak - Bank of Khartoum',
                  id: window.location.hostname || undefined,
                },
                user: {
                  id: userSub,
                  name: 'bankak_customer',
                  displayName: 'Bankak Customer',
                },
                pubKeyCredParams: [
                  { alg: -7, type: 'public-key' },   // ES256
                  { alg: -257, type: 'public-key' }  // RS256
                ],
                authenticatorSelection: {
                  authenticatorAttachment: 'platform', // Directly targets the device's built-in fingerprint / face sensor
                  userVerification: 'required',
                },
                timeout: 60000,
              },
            });
          } catch (e: any) {
            // User cancelled or fallback
            if (e?.name === 'NotAllowedError') {
              setIsAuthenticating(false);
              return;
            }
          }
        }
      }

      await new Promise((resolve) => setTimeout(resolve, 400));
      setIsAuthenticating(false);
      setIsAuthenticated(true);

      // Directly navigate to banking page
      try {
        window.location.assign(IBOK_URL);
      } catch (_e) {
        // Fallback
      }
    } catch (_err) {
      setIsAuthenticating(false);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  const isRtl = lang === 'ar';

  return (
    <div
      dir={isRtl ? 'rtl' : 'ltr'}
      className="min-h-screen bg-[#040806] text-slate-100 flex flex-col font-sans select-none antialiased"
    >
      {/* 1. CLEAN, BEAUTIFUL SPLASH SCREEN (NO EXTRA TEXT, NO END-TO-END) */}
      {showSplash ? (
        <div
          className={`fixed inset-0 z-50 bg-gradient-to-b from-[#020d08] via-[#040907] to-[#010403] flex flex-col items-center justify-center p-8 transition-all duration-500 ease-out ${
            splashFadeOut ? 'opacity-0 scale-95' : 'opacity-100 scale-100'
          }`}
        >
          {/* Subtle Ambient Glow */}
          <div className="absolute w-80 h-80 rounded-full bg-red-600/15 blur-3xl pointer-events-none" />

          {/* Centerpiece: Glowing Official Bankak Icon & Clean Title */}
          <div className="relative flex flex-col items-center text-center">
            <div className="relative mb-6">
              <div className="absolute -inset-3 rounded-full bg-gradient-to-r from-red-600 to-amber-500 opacity-25 blur-md animate-pulse" />
              <img
                src={bankakLogo}
                alt="Bankak"
                className="relative w-36 h-36 rounded-full object-cover shadow-2xl ring-4 ring-white/10"
              />
            </div>

            <h1 className="text-4xl font-black text-white tracking-wide">
              بنكك
            </h1>
            <h2 className="text-xs font-bold text-amber-400 tracking-[0.25em] uppercase mt-1">
              BANKAK
            </h2>

            {/* Clean Progress Line (No text, no percentage, no technical labels) */}
            <div className="w-36 h-1 bg-white/10 rounded-full overflow-hidden mt-8">
              <div
                className="h-full bg-gradient-to-r from-red-600 via-amber-400 to-red-600 rounded-full transition-all duration-500 ease-out"
                style={{ width: `${splashProgress}%` }}
              />
            </div>
          </div>
        </div>
      ) : !isAuthenticated ? (
        /* 2. PURE & SIMPLE SCREEN: LOGO + TITLE + SINGLE BIOMETRIC BUTTON (NO ZIP, NO EXTRA INFO) */
        <div className="flex-1 flex flex-col items-center justify-center p-6 min-h-screen relative">
          {/* Subtle Language Switcher */}
          <div className="absolute top-6 right-6 rtl:right-auto rtl:left-6">
            <button
              onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
              className="flex items-center space-x-1.5 rtl:space-x-reverse text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-full bg-slate-900/60 border border-slate-800 transition"
            >
              <Globe size={13} />
              <span>{lang === 'ar' ? 'English' : 'العربية'}</span>
            </button>
          </div>

          <div className="flex flex-col items-center text-center max-w-xs w-full">
            {/* Attached Bankak Official Icon */}
            <div className="mb-6 transform hover:scale-105 transition-transform duration-300">
              <img
                src={bankakLogo}
                alt="Bankak"
                className="w-28 h-28 rounded-full object-cover shadow-2xl shadow-red-950 ring-4 ring-white/10"
              />
            </div>

            {/* App Name */}
            <h1 className="text-2xl font-bold text-white tracking-tight">
              {lang === 'ar' ? 'بنكك' : 'Bankak'}
            </h1>
            <p className="text-xs text-slate-400 font-medium tracking-wide mt-1 mb-10">
              {lang === 'ar' ? 'بنك الخرطوم' : 'Bank of Khartoum'}
            </p>

            {/* THE ONLY BUTTON: Biometric Login */}
            <button
              onClick={handleBiometricAuth}
              disabled={isAuthenticating}
              className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 active:scale-[0.98] text-white font-bold text-base shadow-xl shadow-red-950/80 border border-red-500/30 transition-all flex items-center justify-center space-x-3 rtl:space-x-reverse cursor-pointer"
            >
              {isAuthenticating ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>{lang === 'ar' ? 'جارٍ التحقق...' : 'Verifying...'}</span>
                </>
              ) : (
                <>
                  <Fingerprint size={22} className="text-white" />
                  <span>{lang === 'ar' ? 'المصادقة بالبصمة' : 'Biometric Login'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      ) : (
        /* 3. BROWSE LINK CONTAINER (AFTER AUTHENTICATION) */
        <div className="flex-1 flex flex-col h-screen overflow-hidden bg-black">
          {/* Header */}
          <header className="h-12 bg-[#070b09] border-b border-red-950/40 px-4 flex items-center justify-between shrink-0 z-30">
            <div className="flex items-center space-x-2.5 rtl:space-x-reverse">
              <img
                src={bankakLogo}
                alt="Bankak"
                className="w-7 h-7 rounded-full object-cover"
              />
              <div className="flex items-center space-x-1.5 rtl:space-x-reverse px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 text-slate-300 text-xs font-mono">
                <Lock size={11} className="text-red-400" />
                <span>ib.bok-sd.com</span>
              </div>
            </div>

            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <button
                onClick={() => setIframeKey((prev) => prev + 1)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white transition"
                title="Reload"
              >
                <RefreshCw size={15} />
              </button>

              <a
                href={IBOK_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-1 rtl:space-x-reverse px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-semibold shadow transition"
              >
                <span>{lang === 'ar' ? 'فتح الرابط' : 'Open Link'}</span>
                <ExternalLink size={12} />
              </a>

              <button
                onClick={handleLogout}
                className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 transition"
                title="Lock"
              >
                <LogOut size={15} />
              </button>
            </div>
          </header>

          {/* Browser Viewport */}
          <div className="flex-1 relative flex flex-col bg-white overflow-hidden">
            <iframe
              key={iframeKey}
              src={IBOK_URL}
              title="Bank of Khartoum Retail Internet Banking"
              className="w-full flex-1 border-0"
              sandbox="allow-forms allow-scripts allow-same-origin allow-popups allow-modals allow-downloads allow-popups-to-escape-sandbox allow-top-navigation"
            />
          </div>
        </div>
      )}
    </div>
  );
}
