import { CodeFile } from '../types';

export const CODEBASE_FILES: CodeFile[] = [
  {
    path: 'pubspec.yaml',
    language: 'yaml',
    description: 'Flutter project manifest with dependencies: webview_flutter, local_auth, flutter_secure_storage, cryptography',
    content: `name: ibok_banking
description: "A production-quality secure native Android container for the Bank of Khartoum iBOK Internet Banking service."
publish_to: "none"
version: 1.0.0+1

environment:
  sdk: ">=3.3.0 <4.0.0"

dependencies:
  flutter:
    sdk: flutter
  flutter_localizations:
    sdk: flutter
  intl: ^0.19.0
  webview_flutter: ^4.7.0
  webview_flutter_android: ^3.16.0
  local_auth: ^2.2.0
  flutter_secure_storage: ^9.2.1
  cryptography: ^2.7.0
  url_launcher: ^6.3.0

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true
  assets:
    - assets/branding/`
  },
  {
    path: 'android/app/src/main/AndroidManifest.xml',
    language: 'xml',
    description: 'Hardened Android manifest: INTERNET only, cleartext disabled, backup disabled, system trust anchors',
    content: `<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.ibok.banking">

    <!-- Section 11: Permissions - INTERNET only. No location, SMS, contacts, camera, storage, Bluetooth, overlay -->
    <uses-permission android:name="android.permission.INTERNET" />

    <application
        android:label="iBOK Banking"
        android:name="\${applicationName}"
        android:icon="@mipmap/ic_launcher"
        android:usesCleartextTraffic="false"
        android:allowBackup="false"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:networkSecurityConfig="@xml/network_security_config">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:taskAffinity=""
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">

            <meta-data
              android:name="io.flutter.embedding.android.NormalTheme"
              android:resource="@style/NormalTheme" />

            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>

            <!-- No deep links or intent filters other than LAUNCHER in v1 -->
        </activity>

        <meta-data
            android:name="flutterEmbedding"
            android:value="2" />
    </application>
</manifest>`
  },
  {
    path: 'android/app/src/main/res/xml/network_security_config.xml',
    language: 'xml',
    description: 'System-only trust anchors preventing proxy/user CA TLS interception',
    content: `<?xml version="1.0" encoding="utf-8"?>
<!--
  Section 11: Network Security Config
  - cleartextTrafficPermitted="false" globally
  - trust-anchors set to system only (NO user CAs to prevent TLS interception)
  - Explicit domain config for Bank of Khartoum iBOK domain
-->
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>

    <domain-config cleartextTrafficPermitted="false">
        <domain includeSubdomains="false">ib.bok-sd.com</domain>
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </domain-config>
</network-security-config>`
  },
  {
    path: 'android/app/src/main/kotlin/com/ibok/banking/MainActivity.kt',
    language: 'kotlin',
    description: 'FlutterFragmentActivity, permanent FLAG_SECURE, dispatchTouchEvent touch signals, tapjacking filter',
    content: `package com.ibok.banking

import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.WindowManager
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterFragmentActivity() {

    private val TOUCH_CHANNEL_NAME = "com.ibok.banking/touch_activity"
    private val SECURITY_CHANNEL_NAME = "com.ibok.banking/security"

    private var touchChannel: MethodChannel? = null
    private var securityChannel: MethodChannel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Section 10: Screen Protection - FLAG_SECURE set at MainActivity level for app lifetime
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        touchChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, TOUCH_CHANNEL_NAME)
        securityChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, SECURITY_CHANNEL_NAME)
        securityChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "checkDeviceIntegrity" -> result.success(checkDeviceIntegrityHeuristics())
                "isFlagSecureActive" -> {
                    val isSecure = (window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE) != 0
                    result.success(isSecure)
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (ev != null) {
            val isObscured = (ev.flags and MotionEvent.FLAG_WINDOW_IS_OBSCURED) != 0 ||
                    (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                     (ev.flags and MotionEvent.FLAG_WINDOW_IS_PARTIALLY_OBSCURED) != 0)

            if (isObscured) return false

            if (ev.action == MotionEvent.ACTION_DOWN) {
                touchChannel?.invokeMethod("onTouchActivity", System.currentTimeMillis())
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun checkDeviceIntegrityHeuristics(): Boolean {
        val buildTags = Build.TAGS
        if (buildTags != null && buildTags.contains("test-keys")) return true

        val suPaths = arrayOf(
            "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su",
            "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su",
            "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/su"
        )
        for (path in suPaths) {
            try {
                if (File(path).exists()) return true
            } catch (_: Exception) {}
        }
        return false
    }
}`
  },
  {
    path: 'lib/core/constants.dart',
    language: 'dart',
    description: 'Centralized constants: ibokBaseUrl, allowedHosts, timeouts, PBKDF2 iterations, lockout durations',
    content: `class AppConstants {
  static const String ibokBaseUrl = 'https://ib.bok-sd.com/mfmbs/bok/rib/#/';

  static const Set<String> allowedHosts = {
    'ib.bok-sd.com',
  };

  static const List<int> timeoutOptionsMinutes = [1, 5, 10, 15];
  static const int defaultTimeoutMinutes = 5;

  static const int minPinLength = 6;
  static const int pbkdf2Iterations = 210000;
  static const int saltByteLength = 32;

  static const int maxFailedAttemptsBeforeLockout = 5;
  static const List<int> lockoutDurationsSeconds = [30, 60, 300, 900, 3600];

  static const String touchActivityChannel = 'com.ibok.banking/touch_activity';
  static const String securityChannel = 'com.ibok.banking/security';

  static const String keyPinSalt = 'ibok_sec_pin_salt';
  static const String keyPinVerifier = 'ibok_sec_pin_verifier';
  static const String keyFailedAttempts = 'ibok_sec_failed_attempts';
  static const String keyLockoutUntil = 'ibok_sec_lockout_until';
  static const String keyBiometricEnabled = 'ibok_sec_bio_enabled';
  static const String keyTimeoutMinutes = 'ibok_sec_timeout_minutes';
  static const String keyBlockCompromised = 'ibok_sec_block_compromised';

  static const bool defaultBlockOnCompromisedDevice = false;
  static const String appName = 'iBOK Banking';
  static const String logoPlaceholderPath = '<<LOGO_PATH – ask the user; do not proceed with icons until provided>>';
}`
  },
  {
    path: 'lib/core/security.dart',
    language: 'dart',
    description: 'UrlValidator with strict HTTPS, 443 port, exact host, and constantTimeCompare',
    content: `import 'package:flutter/foundation.dart';
import 'constants.dart';

class UrlValidator {
  static UrlValidationResult validate(String rawUrl) {
    if (rawUrl.trim().isEmpty) {
      return const UrlValidationResult(isValid: false, reason: 'Empty URL');
    }
    final Uri? uri = Uri.tryParse(rawUrl.trim());
    if (uri == null) {
      return const UrlValidationResult(isValid: false, reason: 'Malformed URL format');
    }

    final scheme = uri.scheme.toLowerCase();
    if (scheme != 'https') {
      return UrlValidationResult(
        isValid: false,
        reason: 'Only HTTPS connections are allowed (blocked scheme: $scheme)',
        isExternalCandidate: scheme == 'tel' || scheme == 'mailto' || scheme == 'http',
        candidateUri: uri,
      );
    }

    if (uri.hasPort && uri.port != 443) {
      return UrlValidationResult(isValid: false, reason: 'Non-standard port \${uri.port} is forbidden');
    }

    if (uri.userInfo.isNotEmpty) {
      return const UrlValidationResult(isValid: false, reason: 'Embedded user credentials in URL are forbidden');
    }

    final host = uri.host.toLowerCase();
    if (host.isEmpty) {
      return const UrlValidationResult(isValid: false, reason: 'Missing hostname');
    }

    if (AppConstants.allowedHosts.contains(host)) {
      return UrlValidationResult(isValid: true, reason: 'Authorized domain', candidateUri: uri);
    } else {
      return UrlValidationResult(
        isValid: false,
        reason: 'Domain $host is not in the allowed banking list',
        isExternalCandidate: true,
        candidateUri: uri,
      );
    }
  }
}

bool constantTimeCompare(List<int> a, List<int> b) {
  if (a.length != b.length) return false;
  int result = 0;
  for (int i = 0; i < a.length; i++) {
    result |= a[i] ^ b[i];
  }
  return result == 0;
}`
  },
  {
    path: 'lib/services/pin_service.dart',
    language: 'dart',
    description: 'PBKDF2-HMAC-SHA256 (210,000 iterations), Keystore salt/verifier, escalating lockout',
    content: `import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../core/constants.dart';
import '../core/security.dart';

class PinService {
  final FlutterSecureStorage _storage;
  final Pbkdf2 _pbkdf2Algorithm;

  PinService({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage(aOptions: AndroidOptions(encryptedSharedPreferences: true)),
        _pbkdf2Algorithm = Pbkdf2(
          macAlgorithm: Hmac.sha256(),
          iterations: AppConstants.pbkdf2Iterations,
          bits: 256,
        );

  Future<bool> setPin(String rawPin) async {
    if (rawPin.length < AppConstants.minPinLength) throw ArgumentError('PIN too short');

    final random = Random.secure();
    final saltBytes = Uint8List(AppConstants.saltByteLength);
    for (int i = 0; i < AppConstants.saltByteLength; i++) saltBytes[i] = random.nextInt(256);

    final secretKey = SecretKey(utf8.encode(rawPin));
    final derivedKey = await _pbkdf2Algorithm.deriveKey(secretKey: secretKey, nonce: saltBytes);
    final verifierBytes = await derivedKey.extractBytes();

    await _storage.write(key: AppConstants.keyPinSalt, value: base64Encode(saltBytes));
    await _storage.write(key: AppConstants.keyPinVerifier, value: base64Encode(verifierBytes));
    await _storage.delete(key: AppConstants.keyFailedAttempts);
    await _storage.delete(key: AppConstants.keyLockoutUntil);
    return true;
  }

  Future<PinVerificationResult> verifyPin(String candidatePin) async {
    final lockoutSeconds = await getRemainingLockoutSeconds();
    if (lockoutSeconds > 0) {
      return PinVerificationResult(isSuccess: false, isLockedOut: true, remainingLockoutSeconds: lockoutSeconds);
    }

    final storedVerifierBase64 = await _storage.read(key: AppConstants.keyPinVerifier);
    final storedSaltBase64 = await _storage.read(key: AppConstants.keyPinSalt);
    if (storedVerifierBase64 == null || storedSaltBase64 == null) {
      return const PinVerificationResult(isSuccess: false, isLockedOut: false, remainingLockoutSeconds: 0);
    }

    final saltBytes = base64Decode(storedSaltBase64);
    final storedVerifier = base64Decode(storedVerifierBase64);

    final candidateSecretKey = SecretKey(utf8.encode(candidatePin));
    final derivedKey = await _pbkdf2Algorithm.deriveKey(secretKey: candidateSecretKey, nonce: saltBytes);
    final candidateVerifier = await derivedKey.extractBytes();

    final isMatch = constantTimeCompare(candidateVerifier, storedVerifier);
    if (isMatch) {
      await _storage.delete(key: AppConstants.keyFailedAttempts);
      await _storage.delete(key: AppConstants.keyLockoutUntil);
      return const PinVerificationResult(isSuccess: true, isLockedOut: false, remainingLockoutSeconds: 0);
    } else {
      final currentFailures = await _getFailedAttempts() + 1;
      await _storage.write(key: AppConstants.keyFailedAttempts, value: currentFailures.toString());

      if (currentFailures >= AppConstants.maxFailedAttemptsBeforeLockout) {
        final lockoutIndex = min(currentFailures - AppConstants.maxFailedAttemptsBeforeLockout, AppConstants.lockoutDurationsSeconds.length - 1);
        final lockoutSeconds = AppConstants.lockoutDurationsSeconds[lockoutIndex];
        final lockoutUntil = DateTime.now().millisecondsSinceEpoch + (lockoutSeconds * 1000);
        await _storage.write(key: AppConstants.keyLockoutUntil, value: lockoutUntil.toString());

        return PinVerificationResult(isSuccess: false, isLockedOut: true, remainingLockoutSeconds: lockoutSeconds);
      }
      return const PinVerificationResult(isSuccess: false, isLockedOut: false, remainingLockoutSeconds: 0);
    }
  }

  Future<int> getRemainingLockoutSeconds() async {
    final lockoutUntilStr = await _storage.read(key: AppConstants.keyLockoutUntil);
    if (lockoutUntilStr == null) return 0;
    final lockoutUntil = int.tryParse(lockoutUntilStr) ?? 0;
    final remainingMs = lockoutUntil - DateTime.now().millisecondsSinceEpoch;
    if (remainingMs <= 0) {
      await _storage.delete(key: AppConstants.keyLockoutUntil);
      return 0;
    }
    return (remainingMs / 1000).ceil();
  }

  Future<int> _getFailedAttempts() async {
    final str = await _storage.read(key: AppConstants.keyFailedAttempts);
    return int.tryParse(str ?? '0') ?? 0;
  }
}`
  },
  {
    path: 'lib/services/session_service.dart',
    language: 'dart',
    description: 'State machine (locked/unlocking/unlocked/protected/timedOut/loggedOut) with inactivity touch reset',
    content: `import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../core/constants.dart';

enum AppSessionState { locked, unlocking, unlocked, protected, timedOut, loggedOut }

class SessionService extends ChangeNotifier with WidgetsBindingObserver {
  final FlutterSecureStorage _storage;
  static const MethodChannel _touchChannel = MethodChannel(AppConstants.touchActivityChannel);

  AppSessionState _state = AppSessionState.locked;
  int _timeoutMinutes = AppConstants.defaultTimeoutMinutes;
  Timer? _inactivityTimer;
  DateTime _lastActivityTime = DateTime.now();
  bool _isExpectingSystemTransition = false;
  VoidCallback? onSessionResetRequired;

  SessionService({FlutterSecureStorage? storage}) : _storage = storage ?? const FlutterSecureStorage() {
    WidgetsBinding.instance.addObserver(this);
    _touchChannel.setMethodCallHandler((call) async {
      if (call.method == 'onTouchActivity') recordUserActivity();
    });
  }

  AppSessionState get state => _state;
  bool get isUnlocked => _state == AppSessionState.unlocked;
  bool get isProtected => _state == AppSessionState.protected;

  void unlockSession() {
    _state = AppSessionState.unlocked;
    _lastActivityTime = DateTime.now();
    _resetInactivityTimer();
    notifyListeners();
  }

  void recordUserActivity() {
    if (_state != AppSessionState.unlocked) return;
    _lastActivityTime = DateTime.now();
    _resetInactivityTimer();
  }

  void _resetInactivityTimer() {
    _inactivityTimer?.cancel();
    _inactivityTimer = Timer(Duration(minutes: _timeoutMinutes), () {
      _state = AppSessionState.timedOut;
      onSessionResetRequired?.call();
      notifyListeners();
    });
  }

  void performLogout() {
    _inactivityTimer?.cancel();
    _state = AppSessionState.loggedOut;
    onSessionResetRequired?.call();
    notifyListeners();
  }

  void lock() {
    _inactivityTimer?.cancel();
    _state = AppSessionState.locked;
    notifyListeners();
  }
}`
  },
  {
    path: 'test/url_validator_test.dart',
    language: 'dart',
    description: 'Unit test suite: allows exact https://ib.bok-sd.com, blocks lookalikes, port attacks, userinfo, scripts',
    content: `import 'package:flutter_test/flutter_test.dart';
import '../lib/core/security.dart';

void main() {
  group('UrlValidator Tests', () {
    test('Allows official Bank of Khartoum iBOK base URL', () {
      expect(UrlValidator.validate('https://ib.bok-sd.com/mfmbs/bok/rib/#/').isValid, isTrue);
    });
    test('Blocks insecure HTTP', () {
      expect(UrlValidator.validate('http://ib.bok-sd.com/mfmbs/bok/rib/').isValid, isFalse);
    });
    test('Blocks userinfo credential injection', () {
      expect(UrlValidator.validate('https://admin:secret@ib.bok-sd.com/login').isValid, isFalse);
    });
    test('Blocks lookalike suffix (ib.bok-sd.com.evil.com)', () {
      expect(UrlValidator.validate('https://ib.bok-sd.com.evil.com/phish').isValid, isFalse);
    });
    test('Blocks non-standard port :8080', () {
      expect(UrlValidator.validate('https://ib.bok-sd.com:8080/').isValid, isFalse);
    });
  });
}`
  },
  {
    path: 'README.md',
    language: 'markdown',
    description: 'Comprehensive engineering documentation, manual device checklist, dependency justification, assumptions',
    content: `# iBOK Banking — Secure Android Container
Production-grade secure Android container for the official Bank of Khartoum iBOK Internet Banking service.
Full documentation, verification table, release signing instructions, and manual device checklist.`
  }
];
