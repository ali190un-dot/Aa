export const ALLOWED_HOSTS = new Set<string>(['ib.bok-sd.com']);
export const IBOK_BASE_URL = 'https://ib.bok-sd.com/mfmbs/bok/rib/';

export interface ValidationOutcome {
  isValid: boolean;
  reason: string;
  isExternalCandidate: boolean;
  parsedHost?: string;
  parsedScheme?: string;
}

export function validateBankingUrl(rawUrl: string): ValidationOutcome {
  const trimmed = rawUrl.trim();
  if (!trimmed) {
    return {
      isValid: false,
      reason: 'Empty URL',
      isExternalCandidate: false,
    };
  }

  try {
    const url = new URL(trimmed);

    // 1. Strict HTTPS scheme
    const scheme = url.protocol.replace(':', '').toLowerCase();
    if (scheme !== 'https') {
      const isExternal = ['tel', 'mailto', 'http'].includes(scheme);
      return {
        isValid: false,
        reason: `Only HTTPS connections are allowed (blocked scheme: ${scheme})`,
        isExternalCandidate: isExternal,
        parsedScheme: scheme,
        parsedHost: url.hostname,
      };
    }

    // 2. Standard HTTPS port only (null or 443)
    if (url.port && url.port !== '443') {
      return {
        isValid: false,
        reason: `Non-standard port :${url.port} is strictly forbidden`,
        isExternalCandidate: false,
        parsedHost: url.hostname,
      };
    }

    // 3. Userinfo check (e.g. username:password@host)
    if (url.username || url.password) {
      return {
        isValid: false,
        reason: 'Embedded user credentials in URL are forbidden',
        isExternalCandidate: false,
        parsedHost: url.hostname,
      };
    }

    // 4. Host allowlist exact match
    const host = url.hostname.toLowerCase();
    if (!host) {
      return {
        isValid: false,
        reason: 'Missing hostname',
        isExternalCandidate: false,
      };
    }

    if (ALLOWED_HOSTS.has(host)) {
      return {
        isValid: true,
        reason: 'Authorized domain (exact match)',
        isExternalCandidate: false,
        parsedHost: host,
        parsedScheme: scheme,
      };
    } else {
      return {
        isValid: false,
        reason: `Domain "${host}" is not in the banking allowlist`,
        isExternalCandidate: true,
        parsedHost: host,
        parsedScheme: scheme,
      };
    }
  } catch (_e) {
    // Check if custom schemes like tel: or mailto: were passed without authority
    if (trimmed.startsWith('tel:') || trimmed.startsWith('mailto:')) {
      const scheme = trimmed.split(':')[0];
      return {
        isValid: false,
        reason: `External scheme detected: ${scheme}`,
        isExternalCandidate: true,
        parsedScheme: scheme,
      };
    }

    return {
      isValid: false,
      reason: 'Malformed URL structure',
      isExternalCandidate: false,
    };
  }
}
