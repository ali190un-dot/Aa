import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Shield,
  Lock,
  Unlock,
  Fingerprint,
  RefreshCw,
  LogOut,
  Settings as SettingsIcon,
  ChevronLeft,
  Globe,
  AlertTriangle,
  Info,
  Clock,
  Trash2,
  ExternalLink,
  CheckCircle,
  Wifi,
  Battery,
  Sliders,
  Smartphone
} from 'lucide-react';
import { AppState, Language } from '../types';
import {
  generateSalt,
  deriveKey,
  constantTimeCompare,
  bytesToBase64,
  base64ToBytes,
  PBKDF2_ITERATIONS,
} from '../utils/crypto';
import { IBOK_BASE_URL } from '../utils/validator';

interface Props {
  onStateChange?: (state: AppState) => void;
  activeTab: 'simulator' | 'testbench' | 'codebase' | 'audit';
}

export const DeviceSimulator: React.FC<Props> = ({ onStateChange }) => {
  // App & Device State
  const [appState, setAppState] = useState<AppState>('splash');
  const [lang, setLang] = useState<Language>('en');
  const [isFlagSecure, setIsFlagSecure] = useState<boolean>(true);
  const [isCompromisedWarning, setIsCompromisedWarning] = useState<boolean>(false);
  const [isOnline, setIsOnline] = useState<boolean>(true);

  // PIN & Cryptography State
  const [storedSalt, setStoredSalt] = useState<string | null>(null);
  const [storedVerifier, setStoredVerifier] = useState<string | null>(null);
  const [pinBuffer, setPinBuffer] = useState<string>('');
  const [confirmingPin, setConfirmingPin] = useState<boolean>(false);
  const [initialPinBuffer, setInitialPinBuffer] = useState<string>('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [failedAttempts, setFailedAttempts] = useState<number>(0);
  const [lockoutRemaining, setLockoutRemaining] = useState<number>(0);
  const [isDerivingKey, setIsDerivingKey] = useState<boolean>(false);

  // Biometrics
  const [bioEnabled, setBioEnabled] = useState<boolean>(true);
  const [showBioModal, setShowBioModal] = useState<boolean>(false);

  // Inactivity Timeout
  const [timeoutMinutes, setTimeoutMinutes] = useState<number>(5);
  const [remainingSessionSeconds, setRemainingSessionSeconds] = useState<number>(300);
  const lastTouchRef = useRef<number>(Date.now());

  // Messages
  const [bannerMessage, setBannerMessage] = useState<string | null>(null);
  const [showExternalWarning, setShowExternalWarning] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // WebView Simulated Page
  const [currentUrl] = useState<string>(IBOK_BASE_URL);
  const [canGoBack, setCanGoBack] = useState<boolean>(false);
  const [exitConfirmOpen, setExitConfirmOpen] = useState<boolean>(false);

  // Notify parent of state changes
  useEffect(() => {
    onStateChange?.(appState);
  }, [appState, onStateChange]);

  // Initial Splash sequence
  useEffect(() => {
    const timer = setTimeout(() => {
      setAppState('lock');
    }, 1200);
    return () => clearTimeout(timer);
  }, []);

  // Lockout countdown timer
  useEffect(() => {
    if (lockoutRemaining <= 0) return;
    const interval = setInterval(() => {
      setLockoutRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setPinError(null);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [lockoutRemaining]);

  // Session Inactivity Countdown (resets on touch inside WebView)
  useEffect(() => {
    if (appState !== 'banking') return;

    const interval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - lastTouchRef.current) / 1000);
      const limit = timeoutMinutes * 60;
      const left = Math.max(0, limit - elapsed);
      setRemainingSessionSeconds(left);

      if (left <= 0) {
        // Trigger inactivity timeout: destroy WebView & lock
        setAppState('timedOut');
        setBannerMessage(
          lang === 'ar'
            ? 'انتهت جلستك الآمنة. يرجى تسجيل الدخول مرة أخرى.'
            : 'Your secure session has expired. Please sign in again.'
        );
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [appState, timeoutMinutes, lang]);

  // Toast auto-dismiss
  useEffect(() => {
    if (!toastMessage) return;
    const t = setTimeout(() => setToastMessage(null), 3000);
    return () => clearTimeout(t);
  }, [toastMessage]);

  // Native touch activity simulator
  const handleTouchActivity = useCallback(() => {
    lastTouchRef.current = Date.now();
    setRemainingSessionSeconds(timeoutMinutes * 60);
  }, [timeoutMinutes]);

  // PIN Operations
  const handleDigit = async (d: string) => {
    if (lockoutRemaining > 0 || isDerivingKey) return;
    if (pinBuffer.length >= 12) return;

    const next = pinBuffer + d;
    setPinBuffer(next);
    setPinError(null);

    // If already has PIN and enters 6 digits, auto-submit
    if (storedVerifier && next.length === 6) {
      await verifyCandidatePin(next);
    }
  };

  const handleDelete = () => {
    if (pinBuffer.length > 0) {
      setPinBuffer(pinBuffer.slice(0, -1));
      setPinError(null);
    }
  };

  // Set / Create 6-digit PIN
  const handleCreatePin = async () => {
    if (pinBuffer.length < 6) {
      setPinError(lang === 'ar' ? 'يجب أن يتكون رمز PIN من 6 أرقام على الأقل' : 'PIN must be at least 6 digits');
      return;
    }

    if (!confirmingPin) {
      setInitialPinBuffer(pinBuffer);
      setPinBuffer('');
      setConfirmingPin(true);
      setPinError(null);
    } else {
      if (pinBuffer === initialPinBuffer) {
        setIsDerivingKey(true);
        try {
          const salt = await generateSalt();
          const derived = await deriveKey(pinBuffer, salt);
          setStoredSalt(bytesToBase64(salt));
          setStoredVerifier(bytesToBase64(derived));
          setConfirmingPin(false);
          setInitialPinBuffer('');
          setPinBuffer('');
          setFailedAttempts(0);
          setAppState('banking');
          handleTouchActivity();
          setToastMessage(lang === 'ar' ? 'تم إنشاء رمز PIN بنجاح' : 'App PIN created successfully');
        } catch (_e) {
          setPinError('Failed to derive cryptographic key');
        } finally {
          setIsDerivingKey(false);
        }
      } else {
        setPinError(lang === 'ar' ? 'رمز PIN غير متطابق. أعد المحاولة' : 'PINs do not match. Try again.');
        setPinBuffer('');
        setConfirmingPin(false);
        setInitialPinBuffer('');
      }
    }
  };

  // Verify PIN with constant-time comparison
  const verifyCandidatePin = async (candidate: string) => {
    if (!storedSalt || !storedVerifier) return;
    setIsDerivingKey(true);
    try {
      const saltBytes = base64ToBytes(storedSalt);
      const expectedVerifier = base64ToBytes(storedVerifier);
      const candidateVerifier = await deriveKey(candidate, saltBytes);

      const isMatch = constantTimeCompare(candidateVerifier, expectedVerifier);
      if (isMatch) {
        setPinBuffer('');
        setFailedAttempts(0);
        setPinError(null);
        setAppState('banking');
        handleTouchActivity();
      } else {
        const nextFailures = failedAttempts + 1;
        setFailedAttempts(nextFailures);
        setPinBuffer('');

        if (nextFailures >= 5) {
          // Escalating lockout schedule: 30s, 60s, 300s...
          const lockoutDurations = [30, 60, 300, 900, 3600];
          const dur = lockoutDurations[Math.min(nextFailures - 5, lockoutDurations.length - 1)];
          setLockoutRemaining(dur);
          setPinError(
            lang === 'ar'
              ? `محاولات خاطئة متكررة. تم حظر الدخول لمدة ${dur} ثانية`
              : `Too many failed attempts. Locked out for ${dur} seconds`
          );
        } else {
          setPinError(
            lang === 'ar'
              ? `رمز PIN غير صحيح. المحاولة ${nextFailures}/5`
              : `Incorrect PIN. Attempt ${nextFailures} of 5`
          );
        }
      }
    } catch (_e) {
      setPinError('Verification error');
    } finally {
      setIsDerivingKey(false);
    }
  };

  // Biometric Unlock Simulation
  const handleBiometricAuth = (success: boolean) => {
    setShowBioModal(false);
    if (success) {
      setPinBuffer('');
      setFailedAttempts(0);
      setPinError(null);
      setAppState('banking');
      handleTouchActivity();
    } else {
      setPinError(lang === 'ar' ? 'فشلت المصادقة البيومترية' : 'Biometric authentication was cancelled or failed');
    }
  };

  // Logout flow
  const handleLogout = () => {
    setAppState('loggedOut');
    setBannerMessage(
      lang === 'ar'
        ? 'تم مسح البيانات المحلية. يرجى استخدام زر تسجيل الخروج في الموقع المصرفي أولاً لإنهاء جلستك على خادم البنك.'
        : 'Local data cleared. Use the iBOK Logout button first to end your session on the bank\'s server.'
    );
  };

  const isRtl = lang === 'ar';

  return (
    <div className="flex flex-col lg:flex-row items-center justify-center gap-8 w-full max-w-6xl mx-auto py-4">
      {/* 1. Android Smartphone Frame */}
      <div className="relative w-[380px] h-[780px] bg-slate-950 rounded-[48px] p-3 shadow-2xl ring-1 ring-slate-800 flex flex-col justify-between select-none">
        {/* Outer Phone Bezel & Hardware Elements */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-36 h-6 bg-slate-900 rounded-b-2xl z-50 flex items-center justify-center space-x-3">
          {/* Front Camera Lens */}
          <div className="w-3.5 h-3.5 bg-slate-950 rounded-full ring-1 ring-slate-800" />
          {/* Speaker grille */}
          <div className="w-12 h-1 bg-slate-800 rounded-full" />
        </div>

        {/* Screen Display Container */}
        <div
          dir={isRtl ? 'rtl' : 'ltr'}
          className="relative w-full h-full bg-slate-900 rounded-[38px] overflow-hidden flex flex-col font-sans text-slate-100"
          onClick={handleTouchActivity}
        >
          {/* Status Bar */}
          <div className="h-10 pt-2 px-6 flex items-center justify-between text-xs text-slate-400 font-medium z-40 bg-slate-900/90 backdrop-blur-sm">
            <span>09:41</span>
            <div className="flex items-center space-x-1.5 rtl:space-x-reverse">
              <span className="text-[10px] font-bold text-emerald-400">4G</span>
              <Wifi size={14} className={isOnline ? 'text-slate-300' : 'text-rose-400'} />
              <Battery size={15} className="text-slate-300" />
            </div>
          </div>

          {/* Screen Content by State */}
          <div className="flex-1 relative flex flex-col overflow-hidden">
            {/* OPAQUE CURTAIN when App is Protected / Backgrounded (FLAG_SECURE Simulation) */}
            {appState === 'protected' && (
              <div className="absolute inset-0 bg-slate-950 z-50 flex flex-col items-center justify-center p-6 text-center">
                <div className="w-20 h-20 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-4 animate-pulse">
                  <Shield size={42} />
                </div>
                <h3 className="text-lg font-bold text-white mb-2">iBOK Banking</h3>
                <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
                  {lang === 'ar'
                    ? 'الجلسة المصرفية محمية بواسطة FLAG_SECURE. التطبيق محجوب لمنع تسريب البيانات.'
                    : 'Banking session shielded by FLAG_SECURE. Screen preview blocked in app switcher.'}
                </p>
                <button
                  onClick={() => {
                    // On resume, require local auth
                    setAppState('lock');
                  }}
                  className="mt-6 px-6 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-full text-xs font-semibold shadow-lg transition"
                >
                  {lang === 'ar' ? 'العودة والمصادقة' : 'Resume & Authenticate'}
                </button>
              </div>
            )}

            {/* A. SPLASH SCREEN */}
            {appState === 'splash' && (
              <div className="flex-1 bg-slate-950 flex flex-col items-center justify-center p-6 text-center animate-fade-in">
                <div className="w-24 h-24 bg-white rounded-2xl flex items-center justify-center shadow-xl mb-6">
                  <span className="text-2xl font-black text-emerald-800 tracking-wider">iBOK</span>
                </div>
                <h1 className="text-xl font-bold tracking-tight text-white mb-1">iBOK Banking</h1>
                <p className="text-xs text-slate-400">
                  {lang === 'ar' ? 'الخدمات المصرفية عبر الإنترنت - بنك الخرطوم' : 'Bank of Khartoum Internet Banking'}
                </p>
                <div className="mt-8 flex items-center space-x-2 text-[11px] text-slate-500">
                  <Shield size={14} className="text-emerald-500" />
                  <span>Hardware Security & Heuristics Check</span>
                </div>
              </div>
            )}

            {/* B. LOCK SCREEN (PIN & Biometric) */}
            {(appState === 'lock' || appState === 'timedOut' || appState === 'loggedOut') && (
              <div className="flex-1 bg-slate-900 flex flex-col justify-between p-5 overflow-y-auto">
                {/* Header bar with Language switcher */}
                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <Shield size={18} className="text-emerald-500" />
                    <span className="text-xs font-semibold text-slate-300">iBOK Security</span>
                  </div>
                  <button
                    onClick={() => setLang(lang === 'en' ? 'ar' : 'en')}
                    className="flex items-center space-x-1 rtl:space-x-reverse text-xs text-slate-400 hover:text-white px-2 py-1 rounded-md bg-slate-800 border border-slate-700"
                  >
                    <Globe size={13} />
                    <span>{lang === 'en' ? 'العربية' : 'English'}</span>
                  </button>
                </div>

                {/* Lock Screen Body */}
                <div className="flex flex-col items-center my-auto py-2">
                  <div className="w-14 h-14 rounded-full bg-emerald-800/80 flex items-center justify-center text-white mb-3 shadow-md">
                    <Lock size={26} />
                  </div>

                  <h2 className="text-lg font-bold text-white mb-1">
                    {lang === 'ar' ? 'خدمات آي بوك المصرفية' : 'iBOK Banking'}
                  </h2>

                  <p className="text-xs text-slate-400 text-center max-w-xs mb-3">
                    {!storedVerifier
                      ? confirmingPin
                        ? lang === 'ar'
                          ? 'تأكيد رمز PIN للتطبيق'
                          : 'Confirm 6-digit App PIN'
                        : lang === 'ar'
                        ? 'إنشاء رمز PIN للتطبيق (6 أرقام على الأقل)'
                        : 'Create App PIN (6 digits minimum)'
                      : lang === 'ar'
                      ? 'أدخل رمز PIN لتسجيل الدخول'
                      : 'Enter 6-digit App PIN to Unlock'}
                  </p>

                  {/* Banner Message (Session Expired or Logged Out) */}
                  {bannerMessage && (
                    <div className="w-full mb-3 p-2.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 text-[11px] flex items-start space-x-2 rtl:space-x-reverse">
                      <Info size={16} className="shrink-0 mt-0.5 text-amber-400" />
                      <span>{bannerMessage}</span>
                    </div>
                  )}

                  {/* Lockout Warning */}
                  {lockoutRemaining > 0 && (
                    <div className="w-full mb-3 p-2.5 bg-rose-500/20 border border-rose-500/40 rounded-xl text-rose-300 text-[11px] flex items-center space-x-2 rtl:space-x-reverse font-medium">
                      <Clock size={16} className="shrink-0 text-rose-400 animate-spin" />
                      <span>
                        {lang === 'ar'
                          ? `تم حظر الدخول مؤقتاً: ${lockoutRemaining} ثانية`
                          : `Temporarily locked out: ${lockoutRemaining}s remaining`}
                      </span>
                    </div>
                  )}

                  {/* Error Message */}
                  {pinError && lockoutRemaining <= 0 && (
                    <div className="text-rose-400 text-[11px] font-semibold text-center mb-2">
                      {pinError}
                    </div>
                  )}

                  {/* PIN Dots */}
                  <div className="flex items-center space-x-3 rtl:space-x-reverse my-2">
                    {[0, 1, 2, 3, 4, 5].map((idx) => {
                      const isFilled = idx < pinBuffer.length;
                      return (
                        <div
                          key={idx}
                          className={`w-3.5 h-3.5 rounded-full transition-all duration-150 ${
                            isFilled
                              ? 'bg-emerald-500 scale-110 shadow-sm shadow-emerald-500/50'
                              : 'bg-slate-700 border border-slate-600'
                          }`}
                        />
                      );
                    })}
                  </div>

                  {isDerivingKey && (
                    <p className="text-[10px] text-emerald-400 mt-1 animate-pulse">
                      PBKDF2 HMAC-SHA256 (210,000 iters)...
                    </p>
                  )}
                </div>

                {/* Keypad */}
                <div className="w-full max-w-[280px] mx-auto pb-2">
                  <div className="grid grid-cols-3 gap-3 text-center">
                    {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                      <button
                        key={digit}
                        onClick={() => handleDigit(digit)}
                        disabled={lockoutRemaining > 0 || isDerivingKey}
                        className="h-14 rounded-full bg-slate-800/80 active:bg-emerald-800 text-lg font-bold text-white border border-slate-700/60 shadow-sm hover:border-slate-500 transition disabled:opacity-40"
                      >
                        {digit}
                      </button>
                    ))}

                    {/* Action button: Submit if creating PIN, else Biometric */}
                    {!storedVerifier ? (
                      <button
                        onClick={handleCreatePin}
                        disabled={pinBuffer.length < 6 || isDerivingKey}
                        className="h-14 rounded-full bg-emerald-700 active:bg-emerald-600 text-white flex items-center justify-center font-bold text-xs disabled:opacity-30 border border-emerald-600"
                      >
                        <CheckCircle size={20} />
                      </button>
                    ) : (
                      <button
                        onClick={() => setShowBioModal(true)}
                        disabled={!bioEnabled || lockoutRemaining > 0}
                        className="h-14 rounded-full bg-slate-800 active:bg-emerald-900 text-emerald-400 flex items-center justify-center border border-slate-700 disabled:opacity-30"
                        title="Biometric Login"
                      >
                        <Fingerprint size={24} />
                      </button>
                    )}

                    <button
                      onClick={() => handleDigit('0')}
                      disabled={lockoutRemaining > 0 || isDerivingKey}
                      className="h-14 rounded-full bg-slate-800/80 active:bg-emerald-800 text-lg font-bold text-white border border-slate-700/60 shadow-sm disabled:opacity-40"
                    >
                      0
                    </button>

                    <button
                      onClick={handleDelete}
                      disabled={lockoutRemaining > 0 || isDerivingKey}
                      className="h-14 rounded-full bg-slate-800 active:bg-slate-700 text-slate-300 flex items-center justify-center border border-slate-700/60 disabled:opacity-40"
                      title="Backspace"
                    >
                      ⌫
                    </button>
                  </div>

                  {/* Secondary Biometrics Button */}
                  {storedVerifier && bioEnabled && lockoutRemaining <= 0 && (
                    <button
                      onClick={() => setShowBioModal(true)}
                      className="w-full mt-3 py-2 flex items-center justify-center space-x-2 rtl:space-x-reverse text-xs text-emerald-400 hover:text-emerald-300 font-semibold"
                    >
                      <Fingerprint size={16} />
                      <span>{lang === 'ar' ? 'تسجيل الدخول بالبصمة' : 'Unlock with Biometrics'}</span>
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* C. BANKING SCREEN (SECURE WEBVIEW CONTAINER) */}
            {appState === 'banking' && (
              <div className="flex-1 flex flex-col bg-slate-900 overflow-hidden">
                {/* Minimal Secure Header */}
                <div className="h-12 bg-slate-950 px-3 flex items-center justify-between border-b border-slate-800 shrink-0">
                  {/* Left: Back */}
                  <button
                    onClick={() => {
                      if (canGoBack) {
                        setCanGoBack(false);
                      } else {
                        setExitConfirmOpen(true);
                      }
                    }}
                    className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition"
                    title="Back"
                  >
                    <ChevronLeft size={20} className={isRtl ? 'rotate-180' : ''} />
                  </button>

                  {/* Refresh */}
                  <button
                    onClick={handleTouchActivity}
                    className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition"
                    title="Reload"
                  >
                    <RefreshCw size={17} />
                  </button>

                  {/* Verified Domain Badge (ib.bok-sd.com) */}
                  <div className="flex items-center space-x-1.5 rtl:space-x-reverse bg-emerald-950/80 border border-emerald-500/40 px-2.5 py-1 rounded-full">
                    <Lock size={12} className="text-emerald-400" />
                    <span className="text-[11px] font-semibold text-emerald-300 tracking-wide">
                      ib.bok-sd.com
                    </span>
                  </div>

                  {/* Settings */}
                  <button
                    onClick={() => setAppState('settings')}
                    className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition"
                    title="Settings"
                  >
                    <SettingsIcon size={18} />
                  </button>

                  {/* Logout */}
                  <button
                    onClick={handleLogout}
                    className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-950/50 transition"
                    title="Logout & Clear Session"
                  >
                    <LogOut size={18} />
                  </button>
                </div>

                {/* Session Inactivity HUD Floating Banner */}
                <div className="bg-slate-950/80 border-b border-slate-800/80 px-3 py-1 flex items-center justify-between text-[11px] text-slate-400">
                  <div className="flex items-center space-x-1.5 rtl:space-x-reverse">
                    <Clock size={12} className="text-emerald-400" />
                    <span>
                      {lang === 'ar' ? 'مهلة النشاط:' : 'Idle Timeout:'}{' '}
                      <strong className="text-slate-200">
                        {Math.floor(remainingSessionSeconds / 60)}:
                        {String(remainingSessionSeconds % 60).padStart(2, '0')}
                      </strong>
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500">Touch to reset timer</span>
                </div>

                {/* Simulated WebView Portal Body */}
                <div className="flex-1 bg-white relative flex flex-col text-slate-900 overflow-y-auto">
                  {/* Mock iBOK Portal Interface matching official structure */}
                  <div className="bg-[#005a36] text-white p-4 shadow-sm">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <div className="w-8 h-8 rounded bg-white flex items-center justify-center text-[#005a36] font-black text-sm">
                          BOK
                        </div>
                        <div>
                          <div className="text-xs font-bold leading-none">Bank of Khartoum</div>
                          <div className="text-[10px] text-emerald-200">iBOK Internet Banking</div>
                        </div>
                      </div>
                      <span className="text-[10px] bg-emerald-800/80 px-2 py-0.5 rounded border border-emerald-600">
                        Official Service
                      </span>
                    </div>
                  </div>

                  {/* Portal Login Box Simulation */}
                  <div className="p-4 space-y-4">
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 shadow-sm">
                      <h4 className="text-sm font-bold text-slate-800 mb-1">
                        {lang === 'ar' ? 'تسجيل الدخول إلى آي بوك' : 'Sign in to iBOK'}
                      </h4>
                      <p className="text-[11px] text-slate-500 mb-3">
                        {lang === 'ar'
                          ? 'تتم إدارة الاعتمادات والـ OTP بالكامل بواسطة خوادم بنك الخرطوم.'
                          : 'Credentials and OTPs are exclusively processed by Bank of Khartoum.'}
                      </p>

                      <div className="space-y-2.5">
                        <div>
                          <label className="block text-[11px] font-medium text-slate-600 mb-1">
                            {lang === 'ar' ? 'اسم المستخدم' : 'Username / CIF'}
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. 1029384"
                            readOnly
                            value="ibok_user_demo"
                            className="w-full text-xs px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-700"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-medium text-slate-600 mb-1">
                            {lang === 'ar' ? 'كلمة المرور' : 'Password'}
                          </label>
                          <input
                            type="password"
                            placeholder="••••••••"
                            readOnly
                            value="secretPassword123"
                            className="w-full text-xs px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-700"
                          />
                        </div>
                        <div className="pt-2">
                          <button
                            type="button"
                            onClick={() => {
                              handleTouchActivity();
                              setToastMessage('Portal touch detected: Session timer reset!');
                            }}
                            className="w-full py-2 bg-[#005a36] hover:bg-[#004d2e] text-white rounded-lg text-xs font-bold shadow transition"
                          >
                            {lang === 'ar' ? 'تسجيل الدخول' : 'Sign In (Bank Server)'}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* External Link Interception Demo Button inside WebView */}
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-[11px] text-amber-900">
                      <p className="font-semibold mb-1 flex items-center space-x-1 rtl:space-x-reverse">
                        <AlertTriangle size={14} className="text-amber-600" />
                        <span>Security Navigation Interceptor</span>
                      </p>
                      <p className="text-[10px] text-amber-700 mb-2">
                        External links or popups trigger a confirmation prompt showing the domain.
                      </p>
                      <button
                        onClick={() => setShowExternalWarning('bankofkhartoum.com')}
                        className="inline-flex items-center space-x-1.5 rtl:space-x-reverse px-2.5 py-1 bg-amber-200 hover:bg-amber-300 text-amber-900 rounded font-semibold text-[10px] transition"
                      >
                        <ExternalLink size={12} />
                        <span>Simulate External Link Click</span>
                      </button>
                    </div>

                    {/* Strict Banking Boundary Notice */}
                    <div className="p-3 bg-slate-100 rounded-xl border border-slate-200 text-[10px] text-slate-600 leading-relaxed">
                      <strong className="text-slate-800">Hard Banking Boundary:</strong> The container executes zero JavaScript injection, no request interception, and stores no credentials.
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* D. SETTINGS SCREEN */}
            {appState === 'settings' && (
              <div className="flex-1 bg-slate-900 flex flex-col p-4 overflow-y-auto">
                <div className="flex items-center space-x-3 rtl:space-x-reverse mb-4">
                  <button
                    onClick={() => setAppState('banking')}
                    className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
                  >
                    <ChevronLeft size={18} className={isRtl ? 'rotate-180' : ''} />
                  </button>
                  <h3 className="text-sm font-bold text-white">
                    {lang === 'ar' ? 'إعدادات الأمان' : 'Security Settings'}
                  </h3>
                </div>

                <div className="space-y-4">
                  {/* Biometric Toggle */}
                  <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 flex items-center justify-between">
                    <div className="flex items-center space-x-2.5 rtl:space-x-reverse">
                      <Fingerprint size={18} className="text-emerald-400" />
                      <div>
                        <div className="text-xs font-semibold text-white">
                          {lang === 'ar' ? 'المصادقة البيومترية' : 'Biometric Unlock'}
                        </div>
                        <div className="text-[10px] text-slate-400">Fingerprint / Face ID</div>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={bioEnabled}
                      onChange={(e) => setBioEnabled(e.target.checked)}
                      className="w-4 h-4 accent-emerald-500 rounded"
                    />
                  </div>

                  {/* Lock Timeout selector */}
                  <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <Clock size={16} className="text-emerald-400" />
                        <span className="text-xs font-semibold text-white">
                          {lang === 'ar' ? 'مهلة القفل التلقائي' : 'Inactivity Lock Timeout'}
                        </span>
                      </div>
                      <span className="text-xs font-bold text-emerald-400">{timeoutMinutes} min</span>
                    </div>
                    <div className="grid grid-cols-4 gap-2">
                      {[1, 5, 10, 15].map((m) => (
                        <button
                          key={m}
                          onClick={() => {
                            setTimeoutMinutes(m);
                            setRemainingSessionSeconds(m * 60);
                          }}
                          className={`py-1.5 text-xs rounded-lg font-bold border transition ${
                            timeoutMinutes === m
                              ? 'bg-emerald-700 border-emerald-500 text-white'
                              : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600'
                          }`}
                        >
                          {m}m
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Clear Local WebView Data */}
                  <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-xs font-semibold text-white">
                          {lang === 'ar' ? 'مسح البيانات المحلية' : 'Clear local WebView data'}
                        </div>
                        <div className="text-[10px] text-slate-400">Cookies, WebStorage, Cache</div>
                      </div>
                      <button
                        onClick={() => {
                          setToastMessage(
                            lang === 'ar'
                              ? 'تم مسح ملفات تعريف الارتباط والذاكرة المؤقتة'
                              : 'All cookies, cache, and WebStorage cleared.'
                          );
                        }}
                        className="px-2.5 py-1 text-[11px] bg-slate-700 hover:bg-slate-600 text-slate-200 rounded font-medium flex items-center space-x-1"
                      >
                        <Trash2 size={12} />
                        <span>Clear</span>
                      </button>
                    </div>
                  </div>

                  {/* Non-disableable Security Invariants */}
                  <div className="p-3 bg-emerald-950/40 rounded-xl border border-emerald-500/20 text-[11px]">
                    <div className="font-bold text-emerald-300 mb-1 flex items-center space-x-1.5">
                      <Shield size={14} className="text-emerald-400" />
                      <span>Non-Disableable Protections</span>
                    </div>
                    <ul className="space-y-1 text-[10px] text-slate-300 list-disc list-inside">
                      <li>Strict HTTPS & System-only Trust Anchors</li>
                      <li>Domain allowlist (ib.bok-sd.com only)</li>
                      <li>FLAG_SECURE permanent screen protection</li>
                      <li>Zero credential extraction</li>
                    </ul>
                  </div>

                  {/* About Button */}
                  <button
                    onClick={() => setAppState('about')}
                    className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center justify-center space-x-2"
                  >
                    <Info size={14} />
                    <span>{lang === 'ar' ? 'حول التطبيق وإخلاء المسؤولية' : 'About & Disclosures'}</span>
                  </button>

                  {/* Logout Button */}
                  <button
                    onClick={handleLogout}
                    className="w-full py-2.5 bg-rose-900/60 hover:bg-rose-900 border border-rose-700 text-rose-200 rounded-xl text-xs font-semibold flex items-center justify-center space-x-2"
                  >
                    <LogOut size={14} />
                    <span>{lang === 'ar' ? 'تسجيل الخروج وإنهاء الجلسة' : 'Logout & Lock Session'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* E. ABOUT SCREEN */}
            {appState === 'about' && (
              <div className="flex-1 bg-slate-900 flex flex-col p-4 overflow-y-auto">
                <div className="flex items-center space-x-3 rtl:space-x-reverse mb-4">
                  <button
                    onClick={() => setAppState('settings')}
                    className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
                  >
                    <ChevronLeft size={18} className={isRtl ? 'rotate-180' : ''} />
                  </button>
                  <h3 className="text-sm font-bold text-white">About iBOK Banking</h3>
                </div>

                <div className="space-y-3 text-xs text-slate-300">
                  {/* Independence Disclosure Box (Section 4) */}
                  <div className="p-3 bg-amber-500/10 border border-amber-500/40 rounded-xl text-amber-300 text-[11px] leading-relaxed">
                    <strong className="block text-amber-200 font-bold mb-1">
                      Independent App Disclosure (Section 4):
                    </strong>
                    This application is an independent client container providing secure access to the official iBOK website (ib.bok-sd.com). It is not published or endorsed by Bank of Khartoum.
                  </div>

                  <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 space-y-2">
                    <p className="flex items-start space-x-2 rtl:space-x-reverse">
                      <CheckCircle size={15} className="text-emerald-400 shrink-0 mt-0.5" />
                      <span>
                        This application provides secure access to the official Bank of Khartoum iBOK Internet Banking website.
                      </span>
                    </p>
                    <p className="flex items-start space-x-2 rtl:space-x-reverse">
                      <CheckCircle size={15} className="text-emerald-400 shrink-0 mt-0.5" />
                      <span>
                        Your banking password and OTP are handled by the official banking website and are not stored by this application.
                      </span>
                    </p>
                    <p className="flex items-start space-x-2 rtl:space-x-reverse">
                      <CheckCircle size={15} className="text-emerald-400 shrink-0 mt-0.5" />
                      <span>
                        Automatic locking helps protect your banking session when the application is inactive.
                      </span>
                    </p>
                  </div>

                  <div className="text-[11px] text-slate-500 text-center pt-2">
                    Build: v1.0.0 (Production Hardened) • Android targetSdk 34
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Toast Notification Notification Pill */}
          {toastMessage && (
            <div className="absolute top-12 left-1/2 -translate-x-1/2 z-50 bg-emerald-600 text-white text-[11px] px-3.5 py-1.5 rounded-full shadow-lg font-medium animate-bounce">
              {toastMessage}
            </div>
          )}

          {/* Biometric Prompt Simulation Modal */}
          {showBioModal && (
            <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-end">
              <div className="w-full bg-slate-900 border-t border-slate-700 rounded-t-3xl p-5 text-center shadow-2xl">
                <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 animate-pulse">
                  <Fingerprint size={36} />
                </div>
                <h4 className="text-sm font-bold text-white mb-1">
                  {lang === 'ar' ? 'المصادقة باستخدام البصمة' : 'Biometric Authentication'}
                </h4>
                <p className="text-[11px] text-slate-400 mb-5">
                  {lang === 'ar' ? 'المس مستشعر البصمة للمتابعة' : 'Touch fingerprint sensor to unlock container'}
                </p>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => handleBiometricAuth(false)}
                    className="py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => handleBiometricAuth(true)}
                    className="py-2.5 rounded-xl bg-emerald-700 text-white text-xs font-semibold hover:bg-emerald-600"
                  >
                    Simulate Match
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* External Link Interception Warning Modal */}
          {showExternalWarning && (
            <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
              <div className="w-full max-w-[300px] bg-slate-900 border border-slate-700 rounded-2xl p-4 text-center shadow-2xl">
                <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <ExternalLink size={24} />
                </div>
                <h4 className="text-sm font-bold text-white mb-1">External Link Warning</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed mb-4">
                  You are about to leave the secure banking session to visit:
                  <span className="block font-mono font-bold text-amber-300 my-1">
                    {showExternalWarning}
                  </span>
                  Do you want to proceed in your external browser?
                </p>
                <div className="flex space-x-2 rtl:space-x-reverse">
                  <button
                    onClick={() => setShowExternalWarning(null)}
                    className="flex-1 py-2 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      setShowExternalWarning(null);
                      setToastMessage('External link opened outside secure container.');
                    }}
                    className="flex-1 py-2 rounded-lg bg-emerald-700 text-white text-xs font-semibold hover:bg-emerald-600"
                  >
                    Proceed
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Exit / Back Confirmation Dialog */}
          {exitConfirmOpen && (
            <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
              <div className="w-full max-w-[300px] bg-slate-900 border border-slate-700 rounded-2xl p-4 text-center shadow-2xl">
                <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center">
                  <Lock size={22} />
                </div>
                <h4 className="text-sm font-bold text-white mb-1">Exit Banking Session?</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed mb-4">
                  Do you want to lock the application and secure your active banking session?
                </p>
                <div className="flex space-x-2 rtl:space-x-reverse">
                  <button
                    onClick={() => setExitConfirmOpen(false)}
                    className="flex-1 py-2 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      setExitConfirmOpen(false);
                      setAppState('lock');
                    }}
                    className="flex-1 py-2 rounded-lg bg-rose-700 text-white text-xs font-semibold hover:bg-rose-600"
                  >
                    Lock App
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Android Home Navigation Bar */}
          <div className="h-9 bg-slate-950/90 flex items-center justify-around px-8 z-40 border-t border-slate-800/60">
            {/* Back button */}
            <button
              onClick={() => {
                if (appState === 'banking') {
                  setExitConfirmOpen(true);
                } else if (appState === 'settings' || appState === 'about') {
                  setAppState('banking');
                }
              }}
              className="text-slate-500 hover:text-white p-1"
            >
              ◀
            </button>
            {/* Home button (triggers app background / FLAG_SECURE curtain) */}
            <button
              onClick={() => {
                if (appState === 'banking') {
                  setAppState('protected');
                }
              }}
              className="text-slate-500 hover:text-white p-1"
              title="Home (Simulate Background App)"
            >
              ●
            </button>
            {/* Recents button */}
            <button
              onClick={() => {
                if (appState === 'banking') {
                  setAppState('protected');
                }
              }}
              className="text-slate-500 hover:text-white p-1"
              title="Recents (FLAG_SECURE Preview)"
            >
              ■
            </button>
          </div>
        </div>
      </div>

      {/* 2. Interactive Simulator Test Controls Panel */}
      <div className="flex-1 max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-5">
            <div className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Sliders size={18} />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Device & Session Controls</h3>
                <p className="text-xs text-slate-400">Live hardware simulation bench</p>
              </div>
            </div>
            <span className="text-[11px] font-mono px-2.5 py-1 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-400 font-semibold">
              State: {appState.toUpperCase()}
            </span>
          </div>

          <div className="space-y-4">
            {/* Fast-Forward Inactivity Timeout */}
            <div className="bg-slate-800/60 p-3.5 rounded-2xl border border-slate-700/70">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-semibold text-white flex items-center space-x-1.5">
                  <Clock size={14} className="text-emerald-400" />
                  <span>Inactivity Timeout Trigger</span>
                </span>
                <span className="text-xs font-mono text-emerald-400">
                  {remainingSessionSeconds}s left
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mb-2.5">
                Test the automatic lock trigger and WebView destruction when user is idle.
              </p>
              <button
                onClick={() => {
                  lastTouchRef.current = Date.now() - timeoutMinutes * 60 * 1000 - 1000;
                  setRemainingSessionSeconds(0);
                  setAppState('timedOut');
                  setBannerMessage(
                    lang === 'ar'
                      ? 'انتهت جلستك الآمنة. يرجى تسجيل الدخول مرة أخرى.'
                      : 'Your secure session has expired. Please sign in again.'
                  );
                }}
                disabled={appState !== 'banking'}
                className="w-full py-2 bg-slate-700 hover:bg-slate-600 disabled:opacity-40 text-white rounded-xl text-xs font-semibold transition"
              >
                Fast-Forward Inactivity Expiration (0s)
              </button>
            </div>

            {/* Background App (FLAG_SECURE Curtain Test) */}
            <div className="bg-slate-800/60 p-3.5 rounded-2xl border border-slate-700/70">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-semibold text-white flex items-center space-x-1.5">
                  <Shield size={14} className="text-emerald-400" />
                  <span>FLAG_SECURE & App Switcher</span>
                </span>
                <span className="text-[10px] text-emerald-400 font-mono">
                  {isFlagSecure ? 'ACTIVE' : 'INACTIVE'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mb-2.5">
                Simulates pressing Home or switching apps: activates opaque curtain and requires re-auth on return.
              </p>
              <button
                onClick={() => setAppState('protected')}
                disabled={appState !== 'banking'}
                className="w-full py-2 bg-slate-700 hover:bg-slate-600 disabled:opacity-40 text-white rounded-xl text-xs font-semibold transition"
              >
                Simulate Backgrounding / Recents Screen
              </button>
            </div>

            {/* Biometric Prompt Trigger */}
            <div className="bg-slate-800/60 p-3.5 rounded-2xl border border-slate-700/70">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-semibold text-white flex items-center space-x-1.5">
                  <Fingerprint size={14} className="text-emerald-400" />
                  <span>Biometric Hardware Signal</span>
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mb-2.5">
                Trigger Android system fingerprint/face dialog via <code className="text-emerald-300">local_auth</code>.
              </p>
              <button
                onClick={() => setShowBioModal(true)}
                className="w-full py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-xs font-semibold transition"
              >
                Show Biometric Dialog
              </button>
            </div>

            {/* Test Navigation Interceptor */}
            <div className="bg-slate-800/60 p-3.5 rounded-2xl border border-slate-700/70">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-semibold text-white flex items-center space-x-1.5">
                  <ExternalLink size={14} className="text-emerald-400" />
                  <span>External Navigation Dialog</span>
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mb-2.5">
                Test domain inspection dialog before launching external system browser.
              </p>
              <button
                onClick={() => setShowExternalWarning('bankofkhartoum.com/contact')}
                className="w-full py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-xs font-semibold transition"
              >
                Test External Link Dialog
              </button>
            </div>
          </div>
        </div>

        {/* Security Specs Footer Badge */}
        <div className="pt-4 border-t border-slate-800 mt-4 flex items-center justify-between text-[11px] text-slate-500 font-mono">
          <span>PBKDF2: 210,000 iters</span>
          <span>minSdk 24 • targetSdk 34</span>
        </div>
      </div>
    </div>
  );
};
