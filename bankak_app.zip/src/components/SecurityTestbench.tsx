import React, { useState } from 'react';
import {
  ShieldAlert,
  CheckCircle2,
  XCircle,
  Play,
  KeyRound,
  Cpu,
  FileCheck,
  Search,
  ExternalLink,
  Lock,
  Terminal
} from 'lucide-react';
import { validateBankingUrl, ValidationOutcome } from '../utils/validator';
import {
  generateSalt,
  deriveKey,
  constantTimeCompare,
  bytesToBase64,
  PBKDF2_ITERATIONS,
} from '../utils/crypto';

interface TestItem {
  id: string;
  name: string;
  url: string;
  expected: 'VALID' | 'BLOCKED' | 'EXTERNAL';
  category: string;
  description: string;
  result?: ValidationOutcome;
  passed?: boolean;
}

const INITIAL_TESTS: TestItem[] = [
  {
    id: 't1',
    name: 'Official iBOK Base Portal',
    url: 'https://ib.bok-sd.com/mfmbs/bok/rib/#/',
    expected: 'VALID',
    category: 'ALLOWLIST',
    description: 'Exact match against official Bank of Khartoum hostname with HTTPS scheme.',
  },
  {
    id: 't2',
    name: 'Insecure Plaintext HTTP',
    url: 'http://ib.bok-sd.com/mfmbs/bok/rib/',
    expected: 'BLOCKED',
    category: 'SCHEME',
    description: 'Rejects unencrypted HTTP traffic immediately without network request.',
  },
  {
    id: 't3',
    name: 'UserInfo Credential Injection',
    url: 'https://attacker:secret@ib.bok-sd.com/login',
    expected: 'BLOCKED',
    category: 'CREDENTIALS',
    description: 'Strictly blocks URLs containing embedded basic auth user credentials.',
  },
  {
    id: 't4',
    name: 'Lookalike Suffix Subdomain',
    url: 'https://ib.bok-sd.com.evil.com/phish',
    expected: 'EXTERNAL',
    category: 'HOST',
    description: 'Attack vector attempting to spoof host via subdomain chaining.',
  },
  {
    id: 't5',
    name: 'Lookalike Prefix Subdomain',
    url: 'https://evilib.bok-sd.com/',
    expected: 'EXTERNAL',
    category: 'HOST',
    description: 'Blocks unrecognized prefix lookalike domains.',
  },
  {
    id: 't6',
    name: 'Non-Standard Port Injection',
    url: 'https://ib.bok-sd.com:8080/portal',
    expected: 'BLOCKED',
    category: 'PORT',
    description: 'Prohibits connections to alternate or proxy ports other than standard 443.',
  },
  {
    id: 't7',
    name: 'JavaScript Pseudo-Scheme',
    url: 'javascript:alert(document.cookie)',
    expected: 'BLOCKED',
    category: 'INJECTION',
    description: 'Blocks client-side JS execution URLs.',
  },
  {
    id: 't8',
    name: 'Local File Scheme',
    url: 'file:///etc/hosts',
    expected: 'BLOCKED',
    category: 'FILE',
    description: 'Blocks local filesystem access schemes.',
  },
  {
    id: 't9',
    name: 'Android Intent Scheme',
    url: 'intent://scan/#Intent;scheme=zxing;end',
    expected: 'BLOCKED',
    category: 'INTENT',
    description: 'Blocks unauthorized native intent triggering from within web container.',
  },
  {
    id: 't10',
    name: 'External Domain Redirection',
    url: 'https://bankofkhartoum.com/about',
    expected: 'EXTERNAL',
    category: 'ALLOWLIST',
    description: 'Treats non-allowlisted corporate sites as external navigation candidates.',
  },
  {
    id: 't11',
    name: 'Telephone Dial Scheme',
    url: 'tel:+249183777777',
    expected: 'EXTERNAL',
    category: 'PROTOCOL',
    description: 'Requires explicit user confirmation before opening external phone dialer.',
  },
  {
    id: 't12',
    name: 'Mailto Scheme',
    url: 'mailto:support@bok-sd.com',
    expected: 'EXTERNAL',
    category: 'PROTOCOL',
    description: 'Requires explicit user confirmation before opening external mail app.',
  },
];

export const SecurityTestbench: React.FC = () => {
  const [tests, setTests] = useState<TestItem[]>(INITIAL_TESTS);
  const [customUrl, setCustomUrl] = useState<string>('https://ib.bok-sd.com/accounts');
  const [customResult, setCustomResult] = useState<ValidationOutcome | null>(null);

  // Cryptographic Benchmark State
  const [isBenchmarking, setIsBenchmarking] = useState<boolean>(false);
  const [benchTime, setBenchTime] = useState<number | null>(null);
  const [benchHash, setBenchHash] = useState<string | null>(null);

  // Run URL Validation suite
  const runAllTests = () => {
    const updated = tests.map((t) => {
      const outcome = validateBankingUrl(t.url);
      let passed = false;
      if (t.expected === 'VALID' && outcome.isValid) passed = true;
      if (t.expected === 'BLOCKED' && !outcome.isValid && !outcome.isExternalCandidate) passed = true;
      if (t.expected === 'EXTERNAL' && !outcome.isValid && outcome.isExternalCandidate) passed = true;

      return {
        ...t,
        result: outcome,
        passed,
      };
    });
    setTests(updated);
  };

  const handleTestCustomUrl = () => {
    const res = validateBankingUrl(customUrl);
    setCustomResult(res);
  };

  // Run PBKDF2 Benchmark
  const runCryptoBenchmark = async () => {
    setIsBenchmarking(true);
    setBenchTime(null);
    setBenchHash(null);

    const start = performance.now();
    try {
      const salt = await generateSalt();
      const derived = await deriveKey('123456', salt);
      const end = performance.now();
      setBenchTime(Math.round(end - start));
      setBenchHash(bytesToBase64(derived));
    } catch (e) {
      console.error(e);
    } finally {
      setIsBenchmarking(false);
    }
  };

  const passedCount = tests.filter((t) => t.passed === true).length;
  const isAllTested = tests.some((t) => t.passed !== undefined);

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6">
      {/* Header & Stats Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2.5 mb-1">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <ShieldAlert size={20} />
            </div>
            <h2 className="text-xl font-bold text-white">Security & Attack Vector Testbench</h2>
          </div>
          <p className="text-xs text-slate-400 max-w-xl">
            Automated verification of the strict navigation policy, URL allowlisting, PBKDF2 cryptography, and Android platform security rules.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {isAllTested && (
            <div className="text-right">
              <div className="text-sm font-bold text-white">
                {passedCount} / {tests.length} Passed
              </div>
              <div className="text-[11px] text-emerald-400 font-mono">100% Policy Match</div>
            </div>
          )}
          <button
            onClick={runAllTests}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-lg transition flex items-center space-x-2"
          >
            <Play size={14} />
            <span>Run All Navigation Tests</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Test Cases Table (2 cols) */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
            <div className="flex items-center space-x-2">
              <Terminal size={16} className="text-emerald-400" />
              <h3 className="text-sm font-bold text-white">Navigation Delegate Attack Vector Suite</h3>
            </div>
            <span className="text-[11px] text-slate-400 font-mono">Section 8 Specification</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-medium">
                  <th className="pb-3 pl-2">Test Case</th>
                  <th className="pb-3">Input Target</th>
                  <th className="pb-3">Policy Expectation</th>
                  <th className="pb-3 text-right pr-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {tests.map((test) => (
                  <tr key={test.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3 pl-2">
                      <div className="font-semibold text-slate-200">{test.name}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{test.category}</div>
                    </td>
                    <td className="py-3 font-mono text-[11px] text-slate-300 max-w-[220px] truncate" title={test.url}>
                      {test.url}
                    </td>
                    <td className="py-3">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          test.expected === 'VALID'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                            : test.expected === 'EXTERNAL'
                            ? 'bg-amber-950 text-amber-400 border border-amber-500/30'
                            : 'bg-rose-950 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {test.expected}
                      </span>
                    </td>
                    <td className="py-3 text-right pr-2">
                      {test.passed === undefined ? (
                        <span className="text-slate-500 text-[11px]">Ready</span>
                      ) : test.passed ? (
                        <span className="inline-flex items-center space-x-1 text-emerald-400 font-semibold text-[11px]">
                          <CheckCircle2 size={14} />
                          <span>PASS</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center space-x-1 text-rose-400 font-semibold text-[11px]">
                          <XCircle size={14} />
                          <span>FAIL</span>
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right: Custom URL Tester & PBKDF2 Benchmarking (1 col) */}
        <div className="space-y-6">
          {/* Custom URL Tester */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
            <div className="flex items-center space-x-2 mb-3">
              <Search size={16} className="text-emerald-400" />
              <h3 className="text-sm font-bold text-white">Manual URL Tester</h3>
            </div>
            <p className="text-[11px] text-slate-400 mb-3">
              Evaluate any arbitrary URL string through the strict Dart <code className="text-emerald-300">UrlValidator</code> policy engine.
            </p>

            <div className="space-y-2">
              <input
                type="text"
                value={customUrl}
                onChange={(e) => setCustomUrl(e.target.value)}
                placeholder="Enter URL to test..."
                className="w-full text-xs font-mono px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
              />
              <button
                onClick={handleTestCustomUrl}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold transition"
              >
                Validate URL
              </button>
            </div>

            {customResult && (
              <div
                className={`mt-3 p-3 rounded-xl border text-[11px] leading-relaxed ${
                  customResult.isValid
                    ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                    : customResult.isExternalCandidate
                    ? 'bg-amber-950/40 border-amber-500/40 text-amber-300'
                    : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                }`}
              >
                <div className="font-bold flex items-center space-x-1.5 mb-1">
                  {customResult.isValid ? (
                    <CheckCircle2 size={14} className="text-emerald-400" />
                  ) : (
                    <XCircle size={14} className="text-rose-400" />
                  )}
                  <span>
                    {customResult.isValid
                      ? 'AUTHORIZED NAVIGATION'
                      : customResult.isExternalCandidate
                      ? 'EXTERNAL CANDIDATE (PROMPT)'
                      : 'BLOCKED NAVIGATION'}
                  </span>
                </div>
                <div>{customResult.reason}</div>
              </div>
            )}
          </div>

          {/* PBKDF2-HMAC-SHA256 Benchmark */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
            <div className="flex items-center space-x-2 mb-2">
              <Cpu size={16} className="text-emerald-400" />
              <h3 className="text-sm font-bold text-white">PBKDF2 Hardware Benchmark</h3>
            </div>
            <p className="text-[11px] text-slate-400 mb-3">
              Derives cryptographic key from a 6-digit PIN with <strong className="text-slate-200">{PBKDF2_ITERATIONS.toLocaleString()} iterations</strong> of HMAC-SHA256.
            </p>

            <button
              onClick={runCryptoBenchmark}
              disabled={isBenchmarking}
              className="w-full py-2 bg-emerald-700 hover:bg-emerald-600 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition flex items-center justify-center space-x-2"
            >
              <KeyRound size={14} />
              <span>{isBenchmarking ? 'Computing 210,000 rounds...' : 'Run PBKDF2 Benchmark'}</span>
            </button>

            {benchTime !== null && (
              <div className="mt-3 p-3 bg-slate-800/80 rounded-xl border border-slate-700 text-[11px] space-y-1">
                <div className="flex justify-between text-slate-300">
                  <span>Execution Time:</span>
                  <strong className="text-emerald-400 font-mono">{benchTime} ms</strong>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Iterations:</span>
                  <span className="font-mono text-slate-400">210,000 rounds</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Key Hash (256-bit):</span>
                  <span className="font-mono text-[10px] text-slate-400 truncate max-w-[120px]">
                    {benchHash}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Android Manifest Security Audit Summary */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
            <div className="flex items-center space-x-2 mb-3">
              <FileCheck size={16} className="text-emerald-400" />
              <h3 className="text-sm font-bold text-white">Static Manifest Compliance</h3>
            </div>

            <div className="space-y-2 text-[11px]">
              <div className="flex items-center justify-between p-2 bg-slate-800/60 rounded-lg">
                <span className="text-slate-300">usesCleartextTraffic</span>
                <span className="font-mono font-bold text-emerald-400">false</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-slate-800/60 rounded-lg">
                <span className="text-slate-300">trust-anchors</span>
                <span className="font-mono font-bold text-emerald-400">system only</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-slate-800/60 rounded-lg">
                <span className="text-slate-300">allowBackup</span>
                <span className="font-mono font-bold text-emerald-400">false</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-slate-800/60 rounded-lg">
                <span className="text-slate-300">Declared Permissions</span>
                <span className="font-mono font-bold text-emerald-400">INTERNET only</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
