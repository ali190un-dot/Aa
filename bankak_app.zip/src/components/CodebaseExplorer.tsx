import React, { useState } from 'react';
import {
  FolderTree,
  FileCode,
  Copy,
  Check,
  Download,
  Terminal,
  ExternalLink,
  Code
} from 'lucide-react';
import JSZip from 'jszip';
import { CODEBASE_FILES } from '../utils/codebase';
import { CodeFile } from '../types';

export const CodebaseExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<CodeFile>(CODEBASE_FILES[0]);
  const [copied, setCopied] = useState<boolean>(false);
  const [isZipping, setIsZipping] = useState<boolean>(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();

      // Add each codebase file to zip package
      for (const f of CODEBASE_FILES) {
        zip.file(f.path, f.content);
      }

      // Add default gitignore
      zip.file(
        '.gitignore',
        `*.class
*.log
*.pyc
*.swp
.DS_Store
.atom/
.buildlog/
.history
.svn/
.idea/
.vscode/
build/
.dart_tool/
.flutter-plugins
.flutter-plugins-dependencies
.packages
android/key.properties
`
      );

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'ibok_banking_android_flutter.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Error generating zip:', e);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2.5 mb-1">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <FolderTree size={20} />
            </div>
            <h2 className="text-xl font-bold text-white">Flutter & Android Codebase Explorer</h2>
          </div>
          <p className="text-xs text-slate-400 max-w-xl">
            Inspect all production-quality source files created in the project repository or download the complete archive ready for <code className="text-emerald-300">flutter build apk --release</code>.
          </p>
        </div>

        <button
          onClick={handleDownloadZip}
          disabled={isZipping}
          className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-lg transition flex items-center space-x-2"
        >
          <Download size={15} />
          <span>{isZipping ? 'Packaging Project...' : 'Download Project (.zip)'}</span>
        </button>
      </div>

      {/* Code Browser Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 min-h-[600px]">
        {/* Left: File Tree (4 cols) */}
        <div className="md:col-span-4 bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-xl flex flex-col">
          <div className="text-xs font-bold text-slate-300 px-3 py-2 mb-2 flex items-center justify-between border-b border-slate-800">
            <span>Project Files ({CODEBASE_FILES.length})</span>
            <span className="text-[10px] text-emerald-400 font-mono">Android & Dart</span>
          </div>

          <div className="space-y-1 overflow-y-auto flex-1 pr-1 font-mono text-xs">
            {CODEBASE_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-3 py-2.5 rounded-xl transition flex items-start space-x-2.5 ${
                    isSelected
                      ? 'bg-emerald-950 border border-emerald-500/40 text-emerald-300'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <FileCode size={15} className={`shrink-0 mt-0.5 ${isSelected ? 'text-emerald-400' : 'text-slate-500'}`} />
                  <div className="overflow-hidden">
                    <div className="truncate font-semibold text-[11px]">{file.path}</div>
                    <div className="text-[10px] text-slate-500 truncate">{file.language.toUpperCase()}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Code Viewer (8 cols) */}
        <div className="md:col-span-8 bg-slate-900 border border-slate-800 rounded-3xl shadow-xl flex flex-col overflow-hidden">
          {/* File Header Bar */}
          <div className="bg-slate-950/80 px-6 py-3 border-b border-slate-800 flex items-center justify-between shrink-0">
            <div>
              <div className="text-xs font-mono font-bold text-emerald-300">{selectedFile.path}</div>
              <div className="text-[10px] text-slate-400">{selectedFile.description}</div>
            </div>

            <button
              onClick={handleCopy}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium flex items-center space-x-1.5 transition"
            >
              {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          {/* File Content Body */}
          <div className="flex-1 p-5 overflow-auto bg-slate-950 font-mono text-[12px] text-slate-300 leading-relaxed select-text">
            <pre className="whitespace-pre-wrap">{selectedFile.content}</pre>
          </div>
        </div>
      </div>
    </div>
  );
};
