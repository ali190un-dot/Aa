import React from 'react';
import {
  ClipboardCheck,
  AlertCircle,
  CheckCircle2,
  Clock,
  Shield,
  FileText,
  Lock,
  ExternalLink
} from 'lucide-react';

export const AuditDashboard: React.FC = () => {
  return (
    <div className="w-full max-w-6xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex items-center justify-between">
        <div>
          <div className="flex items-center space-x-2.5 mb-1">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <ClipboardCheck size={20} />
            </div>
            <h2 className="text-xl font-bold text-white">Engineering Phases & Verification Audit</h2>
          </div>
          <p className="text-xs text-slate-400">
            Phase-by-phase execution status, manual device checklist, and architectural disclosures per master spec v2.
          </p>
        </div>

        <span className="text-xs font-mono px-3 py-1.5 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-400 font-semibold">
          Phases 1–5 Built & Audited
        </span>
      </div>

      {/* Grid of Phase Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Phase 1: Discovery & Missing Input Disclosures */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <span className="w-6 h-6 rounded-full bg-emerald-800 text-emerald-200 text-xs flex items-center justify-center">1</span>
              <span>Phase 1: Discovery & Branding Audit</span>
            </h3>
            <span className="text-[10px] text-amber-400 font-bold px-2 py-0.5 rounded-full bg-amber-950 border border-amber-500/30">
              Open Question Noted
            </span>
          </div>

          <div className="space-y-3 text-xs text-slate-300">
            <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 space-y-1">
              <div className="font-bold flex items-center space-x-1.5">
                <AlertCircle size={14} className="text-amber-400 shrink-0" />
                <span>Logo Placeholder Status (Section 4):</span>
              </div>
              <p className="text-[11px] leading-relaxed">
                As required by Section 4 (&quot;Do not download, redraw, recreate, recolor, add effects to, or AI-generate any logo&quot;), launcher icons are halted and marked with placeholder:
                <code className="block mt-1 p-1 bg-slate-900 rounded font-mono text-[10px] text-amber-200">
                  &lt;&lt;LOGO_PATH – ask the user; do not proceed with icons until provided&gt;&gt;
                </code>
              </p>
            </div>

            <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700/80 space-y-1.5">
              <div className="font-bold text-white">Bank Authorization Disclosure:</div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Independent App Disclosure added to the About screen and README:
                <em>&quot;This application is an independent app providing access to the official iBOK website and is not published by Bank of Khartoum.&quot;</em>
              </p>
            </div>
          </div>
        </div>

        {/* Phase 2: Foundation & Hardening */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <span className="w-6 h-6 rounded-full bg-emerald-800 text-emerald-200 text-xs flex items-center justify-center">2</span>
              <span>Phase 2: Foundation & Android Hardening</span>
            </h3>
            <span className="text-[10px] text-emerald-400 font-bold px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-500/30">
              Verified
            </span>
          </div>

          <ul className="space-y-2 text-xs text-slate-300">
            <li className="flex items-start space-x-2">
              <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>AndroidManifest.xml:</strong> Declared <code className="text-emerald-300">android.permission.INTERNET</code> only. No contacts, SMS, storage, camera, or overlays.
              </span>
            </li>
            <li className="flex items-start space-x-2">
              <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Cleartext Disabled:</strong> <code className="text-emerald-300">usesCleartextTraffic=&quot;false&quot;</code> and <code className="text-emerald-300">allowBackup=&quot;false&quot;</code>.
              </span>
            </li>
            <li className="flex items-start space-x-2">
              <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>System Trust Anchors Only:</strong> <code className="text-emerald-300">network_security_config.xml</code> excludes user-installed CA certificates.
              </span>
            </li>
            <li className="flex items-start space-x-2">
              <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Dual-Language Localization:</strong> Full Arabic (العربية) RTL and English LTR dictionaries in <code className="text-emerald-300">lib/core/l10n.dart</code>.
              </span>
            </li>
          </ul>
        </div>

        {/* Phase 3: Local Security */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <span className="w-6 h-6 rounded-full bg-emerald-800 text-emerald-200 text-xs flex items-center justify-center">3</span>
              <span>Phase 3: Local Security & PIN Cryptography</span>
            </h3>
            <span className="text-[10px] text-emerald-400 font-bold px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-500/30">
              Verified
            </span>
          </div>

          <ul className="space-y-2 text-xs text-slate-300">
            <li className="flex items-start space-x-2">
              <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>PBKDF2-HMAC-SHA256:</strong> 210,000 iterations using <code className="text-emerald-300">cryptography</code> package. Keystore-backed salt and verifier in <code className="text-emerald-300">flutter_secure_storage</code>.
              </span>
            </li>
            <li className="flex items-start space-x-2">
              <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Escalating Lockout:</strong> 5 failed attempts locks out for 30s, 60s, 300s, 900s, 3600s persisted across restarts.
              </span>
            </li>
            <li className="flex items-start space-x-2">
              <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Touch Activity Signal:</strong> Overrides native <code className="text-emerald-300">dispatchTouchEvent</code> in <code className="text-emerald-300">MainActivity.kt</code>; sends timestamp only (zero coordinates).
              </span>
            </li>
            <li className="flex items-start space-x-2">
              <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>FLAG_SECURE:</strong> Active permanently at native level to block screenshots and recents previews.
              </span>
            </li>
          </ul>
        </div>

        {/* Phase 4: WebView Container */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <span className="w-6 h-6 rounded-full bg-emerald-800 text-emerald-200 text-xs flex items-center justify-center">4</span>
              <span>Phase 4: WebView Perimeter & Navigation Policy</span>
            </h3>
            <span className="text-[10px] text-emerald-400 font-bold px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-500/30">
              Verified
            </span>
          </div>

          <ul className="space-y-2 text-xs text-slate-300">
            <li className="flex items-start space-x-2">
              <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Strict Allowlist:</strong> Strictly restricted to <code className="text-emerald-300">ib.bok-sd.com</code>. Blocks http, file, content, javascript, and data schemes.
              </span>
            </li>
            <li className="flex items-start space-x-2">
              <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>External Link Dialog:</strong> Shows target domain in confirmation dialog before launching external system browser.
              </span>
            </li>
            <li className="flex items-start space-x-2">
              <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>No JS Injection:</strong> Zero DOM manipulation, zero form scraping, no JS channels, no cookie extraction.
              </span>
            </li>
            <li className="flex items-start space-x-2">
              <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Session Cleanup:</strong> Destroys controller and wipes cookies/cache/WebStorage upon logout or timeout.
              </span>
            </li>
          </ul>
        </div>
      </div>

      {/* Manual Device Verification Checklist (Section 0 & 15) */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <Clock size={18} className="text-amber-400" />
            <h3 className="text-sm font-bold text-white">Manual Device Checklist (Physical Handset Required)</h3>
          </div>
          <span className="text-[11px] text-amber-300 font-mono font-semibold">
            Status: UNVERIFIED – manual check required
          </span>
        </div>

        <p className="text-xs text-slate-400">
          Per Section 0 (&quot;Never claim something is verified unless you actually ran it... mark it UNVERIFIED – manual check required&quot;), physical device testing items are recorded below:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          {[
            'Biometric enrollment, success, failure, cancel, and device credential fallback on Android hardware.',
            'Screenshot and screen recording blocked by FLAG_SECURE (recents card appears blank in OS switcher).',
            'Inactivity timeout triggers automatic WebView destruction after 1, 5, 10, or 15 minutes of idle time.',
            'In-WebView touch gestures reset the timer via native dispatchTouchEvent timestamp channel.',
            'Backgrounding (Home button) enforces immediate re-authentication upon app resumption.',
            'Live Bank of Khartoum iBOK web portal OTP SMS verification succeeds without rendering bugs.',
            'User-installed proxy CA certificates are rejected by Android networkSecurityConfig.',
            'adb shell dumpsys package confirms only android.permission.INTERNET is granted.',
            'WebView remote debugging (chrome://inspect) is unattachable in release builds.',
          ].map((item, i) => (
            <div key={i} className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60 flex items-start space-x-2.5">
              <span className="text-amber-400 font-bold shrink-0 mt-0.5">●</span>
              <span className="text-slate-300 leading-relaxed">{item}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
