export type AppState =
  | 'splash'
  | 'lock'
  | 'banking'
  | 'settings'
  | 'about'
  | 'protected' // Backgrounded with opaque curtain
  | 'timedOut'
  | 'loggedOut';

export type Language = 'en' | 'ar';

export interface PinState {
  hasPin: boolean;
  isCreating: boolean;
  confirming: boolean;
  initialPin: string;
  pinBuffer: string;
  failedAttempts: number;
  lockoutUntil: number | null;
  errorMessage: string | null;
}

export interface SecurityTestCase {
  id: string;
  name: string;
  inputUrl: string;
  expectedResult: 'VALID' | 'BLOCKED' | 'EXTERNAL_PROMPT';
  category: 'SCHEME' | 'HOST' | 'USERINFO' | 'PORT' | 'PATH' | 'PROTOCOL';
  description: string;
  actualResult?: 'VALID' | 'BLOCKED' | 'EXTERNAL_PROMPT';
  passed?: boolean;
  details?: string;
}

export interface CodeFile {
  path: string;
  language: string;
  content: string;
  description: string;
}
